/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "board.h"

//*****************************************************************************
//
// Board Configurations
// Initializes the rest of the modules.
// Call this function in your application if you wish to do all module
// initialization.
// If you wish to not use some of the initializations, instead of the
// Board_init use the individual Module_inits
//
//*****************************************************************************
void Board_init()
{
    EALLOW;

    PinMux_init();
    INPUTXBAR_init();
    CLB_init();
    CLBXBAR_init();
    OUTPUTXBAR_init();

    EDIS;
}

//*****************************************************************************
//
// PINMUX Configurations
//
//*****************************************************************************
void PinMux_init()
{
    //
    // PinMux for modules assigned to CPU1
    //

    //
    // OUTPUTXBAR1 -> myOUTPUTXBAR1 Pinmux
    //
    GPIO_setPinConfig(myOUTPUTXBAR1_OUTPUTXBAR_PIN_CONFIG);

}

//*****************************************************************************
//
// CLB Configurations
//
//*****************************************************************************
void CLB_init(){
    myCLBTILE1_init();
}

void myCLBTILE1_init(){
//    CLB_setOutputMask(myCLBTILE1_BASE,
//                (0UL << 0UL) |
//                (1UL << 4UL), true);
    //
    // myCLBTILE1 CLB_IN0 initialization
    //
    CLB_configLocalInputMux(myCLBTILE1_BASE, CLB_IN0, CLB_LOCAL_IN_MUX_GLOBAL_IN);
    CLB_configGlobalInputMux(myCLBTILE1_BASE, CLB_IN0, CLB_GLOBAL_IN_MUX_CLB_AUXSIG0);
    CLB_configGPInputMux(myCLBTILE1_BASE, CLB_IN0, CLB_GP_IN_MUX_EXTERNAL);

    CLB_selectInputFilter(myCLBTILE1_BASE, CLB_IN0, CLB_FILTER_NONE);
    //
    // myCLBTILE1 CLB_IN1 initialization
    //
    CLB_configLocalInputMux(myCLBTILE1_BASE, CLB_IN1, CLB_LOCAL_IN_MUX_GLOBAL_IN);
    CLB_configGlobalInputMux(myCLBTILE1_BASE, CLB_IN1, CLB_GLOBAL_IN_MUX_CLB_AUXSIG1);
    CLB_configGPInputMux(myCLBTILE1_BASE, CLB_IN1, CLB_GP_IN_MUX_EXTERNAL);

    CLB_selectInputFilter(myCLBTILE1_BASE, CLB_IN1, CLB_FILTER_NONE);
    //
    // myCLBTILE1 CLB_IN2 initialization
    //
    CLB_configLocalInputMux(myCLBTILE1_BASE, CLB_IN2, CLB_LOCAL_IN_MUX_GLOBAL_IN);
    CLB_configGlobalInputMux(myCLBTILE1_BASE, CLB_IN2, CLB_GLOBAL_IN_MUX_EPWM1A);
    CLB_configGPInputMux(myCLBTILE1_BASE, CLB_IN2, CLB_GP_IN_MUX_EXTERNAL);

    CLB_selectInputFilter(myCLBTILE1_BASE, CLB_IN2, CLB_FILTER_NONE);
    CLB_setGPREG(myCLBTILE1_BASE,0);
    initTILE1(myCLBTILE1_BASE);
    CLB_enableCLB(myCLBTILE1_BASE);
}

//*****************************************************************************
//
// CLBXBAR Configurations
//
//*****************************************************************************
void CLBXBAR_init(){
    myCLBXBAR0_init();
    myCLBXBAR1_init();
}

void myCLBXBAR0_init(){

    XBAR_setCLBMuxConfig(myCLBXBAR0, XBAR_CLB_MUX01_INPUTXBAR1);
    XBAR_enableCLBMux(myCLBXBAR0, myCLBXBAR0_ENABLED_MUXES);
}
void myCLBXBAR1_init(){

    XBAR_setCLBMuxConfig(myCLBXBAR1, XBAR_CLB_MUX03_INPUTXBAR2);
    XBAR_enableCLBMux(myCLBXBAR1, myCLBXBAR1_ENABLED_MUXES);
}

//*****************************************************************************
//
// INPUTXBAR Configurations
//
//*****************************************************************************
void INPUTXBAR_init(){
    myINPUTXBARINPUT1_init();
    myINPUTXBARINPUT2_init();
}

void myINPUTXBARINPUT1_init(){
    XBAR_setInputPin(myINPUTXBARINPUT1_INPUT, myINPUTXBARINPUT1_SOURCE);
}
void myINPUTXBARINPUT2_init(){
    XBAR_setInputPin(myINPUTXBARINPUT2_INPUT, myINPUTXBARINPUT2_SOURCE);
}

//*****************************************************************************
//
// OUTPUTXBAR Configurations
//
//*****************************************************************************
void OUTPUTXBAR_init(){
    myOUTPUTXBAR1_init();
}

void myOUTPUTXBAR1_init(){
    XBAR_setOutputLatchMode(myOUTPUTXBAR1, false);
    XBAR_invertOutputSignal(myOUTPUTXBAR1, false);

    //
    //Mux configuration
    //
    XBAR_setOutputMuxConfig(myOUTPUTXBAR1, XBAR_OUT_MUX01_CLB1_OUT4);
    XBAR_enableOutputMux(myOUTPUTXBAR1, XBAR_MUX01);
}

