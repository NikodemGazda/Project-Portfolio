                /**
 * main.c
 * @author:
 * uP2 - Fall 2022
 */

// Required headers and definitions
#include <G8RTOS_Lab2/G8RTOS_Semaphores.h>
#include <G8RTOS_Lab2/G8RTOS_Structures.h>
#include "threads.h"
#include "driverlib/watchdog.h"
#include "inc/hw_memmap.h"
#include "inc/tm4c123gh6pm.h"
#include "BoardSupport/inc/BoardInitialization.h"
#include <stdbool.h>


void BSP_InitBoard(void);   //Function prototype

int main(void)
{

    // Initialize the G8RTOS
    G8RTOS_Init();
    // Initialize the BSP
    bool isBoardSetup = InitializeBoard(); // initialize board
    G8RTOS_InitFIFO(0); //accel x
    G8RTOS_InitFIFO(1); //accel y
    G8RTOS_InitFIFO(2); //joystick x
    G8RTOS_InitFIFO(3); //joystick y

    //adding game starting threads
    G8RTOS_AddThread(&idleThread,235+idleID,idleID);   //idle thread
    G8RTOS_AddThread(&MainMenuThread,235+MainMenuID,MainMenuID);   //idle thread

    //creating obstacles
    uint16_t obsCounter = 0;
    for (int i = 0; i < 36; i++)    {
        for (int j = 0; j < 12; j++)    {
            obstacles[obsCounter].xCoor = 45 + j*(blockWidth+1);
            obstacles[obsCounter].yCoor = 15 + i*(blockWidth+1);
            obstacles[obsCounter].color = 0x0;
            obstacles[obsCounter].alive = 0;
            obstacles[obsCounter].collision = 0;
            obstacles[obsCounter].special = rand()%10;
            obsCounter++;
        }
    }

    // Add periodic thread 0 and 1
    G8RTOS_AddPeriodicEvent(&PthreadReadAccels,50,0);
    G8RTOS_AddPeriodicEvent(&PthreadReadFIFOs,50,1);
    G8RTOS_AddPeriodicEvent(&PthreadFixScreen,5000,2);

    //draw menu
    LCD_Clear(0x0128);
    LCD_DrawRectangle(120,115,20,90,0xe300); //first option
    for (int i = 0; i < 3; i++) {
        LCD_DrawRectangle(115+35*i,110,5,100,0x0);
        LCD_DrawRectangle(140+35*i,110,5,100,0x0);
        LCD_DrawRectangle(120+35*i,110,20,5,0x0);
        LCD_DrawRectangle(120+35*i,205,20,5,0x0);
    }
    LCD_Text(177,137,"Slow",0xffff);
    LCD_DrawRectangle(155,115,20,90,0xe300); //first option
    LCD_Text(173,172,"Mid",0xffff);
    LCD_DrawRectangle(190,115,20,90,0xe300); //first option
    LCD_Text(200,206,"Impossible",0xffff);
    //gatorbreaker logo
    for (int j = 0; j < 40; j++) {
        for(int i = 0; i < 13; i++) {
            if (title[i][j] == 0) {
                LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0128);
            } else if (title[i][j] == 1) {
                LCD_DrawRectangle(i*7+10,295-j*7,7,7,0xfca0);
            } else if (title[i][j] == 2) {
                LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0400);
            } else if (title[i][j] == 3) {
                LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0);
            } else {
                LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x1f);
            }
        }
    }

    // Launch the G8RTOS
    G8RTOS_Launch();

	while(1){}
}


