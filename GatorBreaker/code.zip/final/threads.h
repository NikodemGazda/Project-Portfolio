#ifndef THREADS_H_
#define THREADS_H_

#include <G8RTOS_Lab2/G8RTOS_Semaphores.h>
#include "G8RTOS_Structures.h"

//constants
#define numObstacles 432
#define numRows 36
#define numCols 12
#define blockWidth 7

// title
extern uint8_t title[13][40];

// Struct object for a 'ball' thread
typedef struct ball_t
{
    int32_t ballID;
    int16_t xCoor;
    int16_t xOldCoor;
    int16_t yCoor;
    int16_t yOldCoor;
    uint16_t ballColor;
    uint16_t prevCol;
    uint16_t alive;
    int16_t xSpeed;
    int16_t ySpeed;
} ball_t;

ball_t balls[20];

//struct for each obstacle in the obstacle array
typedef struct obstacle_t
{
    int8_t collision;
    int16_t xCoor;
    int16_t yCoor;
    uint16_t color;
    uint8_t alive;
    uint8_t special;
} obstacle_t;

obstacle_t obstacles[numObstacles];

//struct for paddle thread
typedef struct paddle_t
{
    int16_t yCoor;
    int16_t yOldCoor;
    int16_t xWidth;
    int16_t yWidth;
    int16_t yAddedSpeed;
    int16_t resetPaddle;
} paddle_t;

// Semaphores
semaphore_t * Sensor_I2C; //for acceleration

//thread IDs
#define MainMenuID 10
#define gameStartID 11
#define gameEndID 12
#define joyWFIFOID 14
#define joyRFIFOID 15
#define paddleID 16
#define drawObstaclesID 17
#define createBallID 18
#define PnLID 19
#define idleID 20


semaphore_t *sensorMutex;
semaphore_t *LEDMutex;

//IRQ
void Button0(void);

//threads
void MainMenuThread(void);
void gameStartThread(void);
void gameEndThread(void);
void joystickWriteThread(void);
void joystickReadThread(void);
void idleThread(void);
void updatePnLThread(void);
void ballThread(void);
void createBallThread(void);
void drawObstaclesThread(void);
void paddleThread(void);

//periodic
void PthreadReadAccels(void);
void PthreadReadFIFOs(void);
void PthreadFixScreen(void);

//functions
//absolute value for int16_t
int16_t abs16(int16_t a);
//draw a 6x6 square
void drawOrange6x6(uint16_t x, uint16_t y, uint16_t color);
//draw a 7x7 square
void draw7x7(uint16_t x, uint16_t y, uint16_t color);
//draw the lives and points banner
void drawBanner();


#endif /* THREADS_H_ */
