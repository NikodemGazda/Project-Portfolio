#include <BoardSupport/inc/bmi160.h>
#include <BoardSupport/inc/Joystick.h>
#include <BoardSupport/inc/opt3001.h>
#include <BoardSupport/inc/RGBLedDriver.h>
#include <G8RTOS_Lab2/G8RTOS_IPC.h>
#include <G8RTOS_Lab2/G8RTOS_Scheduler.h>
#include <sys/_stdint.h>
#include <threads.h>
#include <utils/uartstdio.h>
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_nvic.h"
#include <stdlib.h>
#include <time.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <math.h>

uint8_t title[13][40] = {{0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,0,0,0,0,0},
                        {1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,2,2,2,3,2,0,0,0,0},
                        {1,0,0,0,1,1,1,0,1,1,1,0,1,1,1,0,1,1,1,0,2,0,2,2,0,2,2,0,2,2,2,2,2,2,2,2,2,2,2,2},
                        {1,0,0,0,1,0,1,0,0,1,0,0,1,0,1,0,1,0,1,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0},
                        {1,0,1,0,1,1,1,0,0,1,0,0,1,0,1,0,1,1,0,0,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2,2},
                        {1,1,1,0,1,0,1,0,0,1,0,0,1,1,1,0,1,0,1,0,2,2,2,2,2,2,2,2,2,2,2,2,2,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,2,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,0,0,0,0,2,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,0,2,0,0,0,0,0,0,0,0,0},
                        {0,0,0,0,0,0,2,2,2,2,2,0,0,4,4,0,0,0,0,0,0,4,4,4,0,0,0,0,0,0,0,0,0,4,4,4,0,0,0,0},
                        {0,0,0,0,2,2,2,2,2,2,2,0,0,4,0,4,0,4,4,4,0,4,0,0,0,4,4,4,0,4,0,4,0,4,0,0,0,4,4,4},
                        {0,0,2,2,2,2,2,2,2,2,2,0,0,4,4,0,0,4,0,4,0,4,4,4,0,4,0,4,0,4,4,0,0,4,4,4,0,4,0,4},
                        {0,2,2,2,2,0,0,2,0,2,0,0,0,4,0,4,0,4,4,0,0,4,0,0,0,4,4,4,0,4,4,0,0,4,0,0,0,4,4,0},
                        {2,2,2,0,0,0,0,2,0,2,0,0,0,4,4,0,0,4,0,4,0,4,4,4,0,4,0,4,0,4,0,4,0,4,4,4,0,4,0,4}};

int16_t accelerometerX;
int32_t Avg = 0;
int16_t FIFOaccelY;
int32_t FIFOJoystickX = 2000;
int32_t FIFOJoystickY = 2000;
uint8_t interruptFlag = 0;
uint16_t numBalls = 0;
int8_t invincible = -1;
paddle_t paddle;
int16_t maxSpeed = 4;
int16_t points = 0;
int16_t lives = 10;
uint8_t state = 0;
uint16_t addBall = 0;
uint32_t joystickData[2];
int8_t option = 0;
uint8_t questionUp = 1;
uint16_t maxScore = 0;

//absolute value function bc apparently the math one only works for ints
int16_t abs16(int16_t a) {
    if (a < 0) {
        return a*-1;
    } else {
        return a;
    }
}


void drawOrange6x6(uint16_t x, uint16_t y, uint16_t color) {
    //POINTS
    LCD_DrawRectangle(x+2,y,6,6,color);
}

void draw7x7(uint16_t x, uint16_t y, uint16_t color) {
    //POINTS
    LCD_DrawRectangle(x*8,y*8,7,7,color);
}

void drawBanner() {
    //POINTS
    //P
    drawOrange6x6(0,302,0xfca0);
    drawOrange6x6(6,302,0xfca0);
    drawOrange6x6(12,302,0xfca0);
    drawOrange6x6(0,304,0xfca0);
    drawOrange6x6(12,304,0xfca0);
    drawOrange6x6(0,310,0xfca0);
    drawOrange6x6(6,310,0xfca0);
    drawOrange6x6(12,310,0xfca0);
    drawOrange6x6(18,310,0xfca0);
    drawOrange6x6(24,310,0xfca0);
    //O
    LCD_DrawRectangle(2,294,30,6,0xfca0);
    LCD_DrawRectangle(2,286,30,6,0xfca0);
    drawOrange6x6(24,292,0xfca0);
    drawOrange6x6(0,292,0xfca0);
    //I
    LCD_DrawRectangle(2,278,30,6,0xfca0);
    //N
    LCD_DrawRectangle(2,270,30,6,0xfca0);
    LCD_DrawRectangle(2,268,6,2,0xfca0);
    LCD_DrawRectangle(2,262,30,6,0xfca0);
    //T
    LCD_DrawRectangle(2,247,6,13,0xfca0);
    LCD_DrawRectangle(2,250,30,6,0xfca0);
    //S
    LCD_DrawRectangle(2,241,18,4,0xfca0);
    LCD_DrawRectangle(14,231,18,4,0xfca0);
    drawOrange6x6(0,231,0xfca0);
    drawOrange6x6(0,235,0xfca0);
    drawOrange6x6(12,235,0xfca0);
    drawOrange6x6(24,235,0xfca0);
    drawOrange6x6(24,239,0xfca0);
    //:
    drawOrange6x6(6,219,0xfca0);
    drawOrange6x6(18,219,0xfca0);
    //LIVES
    //L
    LCD_DrawRectangle(2,133,30,6,0xfca0);
    LCD_DrawRectangle(26,121,6,12,0xfca0);
    //I
    LCD_DrawRectangle(2,113,30,6,0xfca0);
    //V
    LCD_DrawRectangle(2,105,18,6,0xfca0);
    LCD_DrawRectangle(2,93,18,6,0xfca0);
    drawOrange6x6(18,102,0xfca0);
    drawOrange6x6(18,96,0xfca0);
    drawOrange6x6(24,99,0xfca0);
    //E
    LCD_DrawRectangle(2,85,30,6,0xfca0);
    drawOrange6x6(0,79,0xfca0);
    drawOrange6x6(12,79,0xfca0);
    drawOrange6x6(24,79,0xfca0);
    //S
    LCD_DrawRectangle(2,71,18,4,0xfca0);
    LCD_DrawRectangle(14,61,18,4,0xfca0);
    drawOrange6x6(0,61,0xfca0);
    drawOrange6x6(0,65,0xfca0);
    drawOrange6x6(12,65,0xfca0);
    drawOrange6x6(24,65,0xfca0);
    drawOrange6x6(24,69,0xfca0);
    //:
    drawOrange6x6(6,49,0xfca0);
    drawOrange6x6(18,49,0xfca0);
    //points and lives
}

//IRQ

void Button0(void)   {
    GPIOIntDisable(GPIO_PORTC_BASE, GPIO_PIN_4);
    IntDisable(INT_GPIOC);  //Disables NVIC interrupt
    interruptFlag = 1;
}


void idleThread(void)
{
    while(1);
}

//writing joystick data to the FIFO
void joystickWriteThread(void) {
    while(1) {
        //read joystick data
        GetJoystickCoordinates(&joystickData);
        // write to joystick FIFO
        writeFIFO(2,joystickData[0]); //x and
        writeFIFO(3,joystickData[1]); //y
        sleep(50);
    }
}

//reading data from the joystick FIFO
void joystickReadThread(void) {
    while(1) {
        // write to joystick FIFO
        FIFOJoystickX = readFIFO(2);
        FIFOJoystickY = readFIFO(3);

        sleep(50);
    }
}

//game menu thread
void gameStartThread(void) {
    int8_t oldOption = option;
    while(1) {

        //cycling thru menu options
        if (FIFOJoystickY > 3000) {
            option++;
            if (option > 2) {
                option = 0;
            }
        } else if (FIFOJoystickY < 1000) {
            option--;
            if (option < 0) {
                option = 2;
            }
        }

        //selecting option based on button interrupt
        if (interruptFlag == 1) {
            //clearing flag and enabling interrupt
            interruptFlag = 0;
            GPIOIntClear(GPIO_PORTC_BASE, GPIO_PIN_4);
            GPIOIntEnable(GPIO_PORTC_BASE, GPIO_PIN_4);
            IntEnable(INT_GPIOC);  //enables NVIC interrupt

            //game options
            lives = option*5+5; //easy mode, 5 lives, hard, 15
            maxSpeed = option*2+2; //spead also increases
            points = 0;
            state = 1;

            //clearing screen
            LCD_Clear(0x0);

            //removing previous threads including this one
            G8RTOS_KillThread(joyWFIFOID);
            G8RTOS_KillThread(joyRFIFOID);
            G8RTOS_AddThread(&MainMenuThread,235+MainMenuID,MainMenuID);
            G8RTOS_KillSelf();
        }

        //moving cursor box
        if (oldOption != option) {
            //erasing old
            LCD_DrawRectangle(115+35*oldOption,110,5,100,0x0);
            LCD_DrawRectangle(140+35*oldOption,110,5,100,0x0);
            LCD_DrawRectangle(120+35*oldOption,110,20,5,0x0);
            LCD_DrawRectangle(120+35*oldOption,205,20,5,0x0);
            //drawing new
            LCD_DrawRectangle(115+35*option,110,5,100,0xffff);
            LCD_DrawRectangle(140+35*option,110,5,100,0xffff);
            LCD_DrawRectangle(120+35*option,110,20,5,0xffff);
            LCD_DrawRectangle(120+35*option,205,20,5,0xffff);
        }

        oldOption = option;
        sleep(200);
    }
}

//thread that controls end game screen
void gameEndThread(void) {
    //kill threads
    G8RTOS_KillThread(paddleID);
    G8RTOS_KillThread(PnLID);
    G8RTOS_KillThread(createBallID);
    G8RTOS_KillThread(drawObstaclesID);

    //add joystick
    G8RTOS_AddThread(&joystickReadThread,235+joyRFIFOID,joyRFIFOID);
    G8RTOS_AddThread(&joystickWriteThread,235+joyWFIFOID,joyWFIFOID);

    //write message
    if (points >= maxScore) { //game won!
        LCD_Clear(0x3da7);
        LCD_Text(264,56,"Congratulations, Player!",0x0);
        LCD_Text(240,87,"You did it. You won.",0x0);
        LCD_Text(176,135,"Nice",0x0);
        LCD_Text(204,163,"Points:",0x0);
        uint16_t temp = points;
        for (int i = 0; i < 3; i++) {
            PutChar(124+8*i,163,temp%10+48,0xffff);
            temp /= 10;
        }
        LCD_Text(280,191,"(Wiggle Joystick To Play Again)",0x0);
    } else { //you lost :/
        LCD_Clear(0x8000);
        LCD_Text(256,56,"That's... disappointing.",0xffff);
        LCD_Text(244,87,"You did it. You lost.",0xffff);
        LCD_Text(168,135,":(",0xffff);
        LCD_Text(204,163,"Points:",0xffff);
        uint16_t temp = points;
        for (int i = 0; i < 3; i++) {
            PutChar(124+8*i,163,temp%10+48,0x0);
            temp /= 10;
        }
        LCD_Text(280,191,"(Wiggle Joystick To Play Again)",0xffff);
    }
    while(1) {
        //check if joystick moved
        if (FIFOJoystickX > 3500 || FIFOJoystickY > 3500) {
            //starting game over
            //draw menu screen
            LCD_Clear(0x0128);
            LCD_DrawRectangle(120,115,20,90,0xe300); //first option
            for (int i = 0; i < 3; i++) {
                LCD_DrawRectangle(115+35*i,110,5,100,0x0);
                LCD_DrawRectangle(140+35*i,110,5,100,0x0);
                LCD_DrawRectangle(120+35*i,110,20,5,0x0);
                LCD_DrawRectangle(120+35*i,205,20,5,0x0);
            }
            LCD_Text(177,137,"Slow",0xffff);
            LCD_DrawRectangle(155,115,20,90,0xe300); //first option
            LCD_Text(173,172,"Mid",0xffff);
            LCD_DrawRectangle(190,115,20,90,0xe300); //first option
            LCD_Text(200,206,"Impossible",0xffff);
            for (int j = 0; j < 40; j++) {
                for(int i = 0; i < 13; i++) {
                    if (title[i][j] == 0) {
                        LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0128);
                    } else if (title[i][j] == 1) {
                        LCD_DrawRectangle(i*7+10,295-j*7,7,7,0xfca0);
                    } else if (title[i][j] == 2) {
                        LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0400);
                    } else if (title[i][j] == 3) {
                        LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x0);
                    } else {
                        LCD_DrawRectangle(i*7+10,295-j*7,7,7,0x1f);
                    }
                }
            }

            state = 0;
            G8RTOS_AddThread(&MainMenuThread,235+MainMenuID,MainMenuID);
            G8RTOS_KillThread(joyRFIFOID);
            G8RTOS_KillThread(joyWFIFOID);
            G8RTOS_KillSelf();
        }
        sleep(50);
    }
}

//state machine thread that adds all the threads necessary for each state
void MainMenuThread(void) {
    while(1) {
        if (state == 0) { //main menu
            G8RTOS_AddThread(&joystickWriteThread,235+joyWFIFOID,joyWFIFOID);  //thread that updates the scoreboard
            G8RTOS_AddThread(&joystickReadThread,235+joyRFIFOID,joyRFIFOID);  //thread that updates the scoreboard
            G8RTOS_AddThread(&gameStartThread,235+gameStartID,gameStartID);  //thread that navigates menu
            G8RTOS_KillSelf();
            sleep(100);
        } else if (state == 1) { //start a game
            G8RTOS_AddThread(&updatePnLThread,235+PnLID,PnLID);  //thread that updates the scoreboard
            G8RTOS_AddThread(&createBallThread,235+createBallID,createBallID); //thread that controls the creation of balls
            G8RTOS_AddThread(&drawObstaclesThread,235+drawObstaclesID,drawObstaclesID); //thread that loads obstacles
            G8RTOS_AddThread(&paddleThread,235+paddleID,paddleID); //thread that controls the paddle
            G8RTOS_KillSelf();
            sleep(100);
        }
    }
}

//thread that updates points and lives in the banner
void updatePnLThread(void)
{
    points = 0;
    uint16_t oldLives = 3;
    uint16_t oldPoints = points;
    uint16_t temp = 0;
    while(1) {
        if (oldLives != lives && invincible != 1) {
            temp = oldLives;
            //erasing old vals
            for (int i = 0; i < 2; i++) {
                PutChar(18+12*i,26,temp%10+48,0x0128);
                temp /= 10;
            }
            temp = lives;
            for (int i = 0; i < 2; i++) {
                PutChar(18+12*i,26,temp%10+48,0xffff);
                temp /= 10;
            }
            oldLives = lives;
        } else if (questionUp == 0 && invincible == 1) {
            questionUp = 1;
            //print that the player is invincible
            LCD_Text(38,26,"???",0xf800);
        }
        if (oldPoints != points) {
            temp = oldPoints;
            //erasing old vals
            if ((temp/10)%10 != (points/10)%10) {
                LCD_DrawRectangle(14,165,12,32,0x0128);
            } else {
                for (int i = 0; i < 3; i++) {
                    PutChar(173+12*i,26,temp%10+48,0x0128);
                    temp /= 10;
                }
            }
            temp = points;
            for (int i = 0; i < 3; i++) {
                PutChar(173+12*i,26,temp%10+48,0xffff);
                temp /= 10;
            }
            oldPoints = points;
        }
        sleep(1000); //update every 5 seconds
    }
}

//thread for each new ball!
void ballThread(void)
{
    uint8_t killself = 0;
    uint16_t ballID = CurrentlyRunningThread->ThreadID;
    while(1)
    {

        //save old xCoor and yCoor to erase previous ball
        balls[ballID].xOldCoor = balls[ballID].xCoor;
        balls[ballID].yOldCoor = balls[ballID].yCoor;

        //ball motion
        int16_t xDif = balls[ballID].xCoor + balls[ballID].xSpeed;
        int16_t yDif = balls[ballID].yCoor + balls[ballID].ySpeed;

        //checking for wall and bouncing if collision
        if (xDif >= 228) {
            //if invincible just bounce off end
            if (invincible == 1) {
                balls[ballID].xSpeed *= -1;
                balls[ballID].xCoor = 228;
            //if not, delete ball
            } else {
                balls[ballID].alive = 0;
                LCD_DrawRectangle(balls[ballID].xOldCoor,balls[ballID].yOldCoor,7,7,0x0000);
                LCD_DrawRectangle(balls[ballID].xCoor,balls[ballID].yCoor,7,7,0x0000);
                numBalls--;
                lives--;
                killself = 1;
                sleep(15);
            }
        } else if (xDif <= 35)   {
            balls[ballID].xSpeed *= -1;
            balls[ballID].xCoor = 35;
        } else {
            balls[ballID].xCoor = xDif;
        }

        if (yDif >= 308) {
            balls[ballID].ySpeed *= -1;
            balls[ballID].yCoor = 308;
        } else if (yDif <= 5)   {
            balls[ballID].ySpeed *= -1;
            balls[ballID].yCoor = 5;
        } else {
            //updating y position
            balls[ballID].yCoor = yDif;
        }

        //collision with obstacle
        uint16_t colFlag = 0;
        int16_t minColDist = 25;
        int16_t obsIndex = 0;
        //loop thru each obstacle
        for (int i = 0; i < numObstacles; i++)  {
            //only proceed if the block hasn't been broken alr
            if ((obstacles[i].alive == 1) &&
                //seeing if the ball is within the x range of the obstacle
                (xDif+6 >= obstacles[i].xCoor) &&
                (xDif <= obstacles[i].xCoor+blockWidth) &&
                //seeing if the ball is within the y range of the obstacle
                (yDif+6 >= obstacles[i].yCoor) &&
                (yDif <= obstacles[i].yCoor+blockWidth)) {

                colFlag = 1;
                //calculate ball distance from current block
                int16_t test = (abs16(balls[ballID].xOldCoor - obstacles[i].xCoor) + abs16(balls[ballID].yOldCoor - obstacles[i].yCoor));
                //choose this block as the one for reflection if it's the closest
                if (test < minColDist ) {
                    minColDist = test;
                    obsIndex = i;
                }
                obstacles[i].collision = 1;
            }
        }

        //if collision detected
        if (colFlag == 1) {

            //removing obstacle
            obstacles[obsIndex].alive = 0;
            LCD_DrawRectangle(obstacles[obsIndex].xCoor, obstacles[obsIndex].yCoor, blockWidth, blockWidth,0x0000);
            points++;
            //if the block is special, create a new ball
            if (obstacles[obsIndex].special == 9) {
                addBall++;
            }

            //also figure out the direction it's going in
            if (balls[ballID].xSpeed > 0 && balls[ballID].ySpeed > 0) { //going down right
                //figuring out which side -- force the ball to choose a block
                //for sure left side
                if ((balls[ballID].yOldCoor+6 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor-7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    //The position after collision is going to be touching where the
                    //obstacle used to be. While touching the obstacle, it would look
                    //better if the position where the ball is touching where the obstacle
                    //used to be were somewhere between the old position and where the new
                    //position would've been had the obstacle not been there, however, this
                    //causes errors if that better position ends up in another obstacle.
                    //therefore, the following if statements check if there's a block in the
                    //better position--if not, that'll be the position. If so, the new position
                    //will snap back to the closest safest location.
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure top side
                } else if ((balls[ballID].yOldCoor+7 <= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor+6 >= obstacles[obsIndex].xCoor))) {
                    //updating position
                    //the first if statement checks if that position is even possible
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                //left side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor+6-obstacles[obsIndex].yCoor)/(balls[ballID].xOldCoor+6.01-obstacles[obsIndex].xCoor))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed > 0 && balls[ballID].ySpeed < 0) { //going up right
                //figuring out which side -- force the ball to choose a block
                //for sure left side
                if ((balls[ballID].yOldCoor <= obstacles[obsIndex].yCoor+6) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor-7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex-numCols-1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure bottom side
                } else if ((balls[ballID].yOldCoor-7 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor+6 >= obstacles[obsIndex].xCoor))) {
                    //updating position
                    if (obsIndex+numCols+1 < numObstacles) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                //left side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor-(obstacles[obsIndex].yCoor+6))/(balls[ballID].xOldCoor+6.01-obstacles[obsIndex].xCoor))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex-numCols-1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex+numCols+1 < numObstacles) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed < 0 && balls[ballID].ySpeed < 0) { //going up left
                //figuring out which side -- force the ball to choose a block
                //for sure right side
                if ((balls[ballID].yOldCoor <= obstacles[obsIndex].yCoor+6) && ((balls[ballID].xOldCoor >= obstacles[obsIndex].xCoor+7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols == numCols-1) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure bottom side
                } else if ((balls[ballID].yOldCoor >= obstacles[obsIndex].yCoor+7) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor+6))) {
                    //updating position
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing y direction
                    balls[ballID].ySpeed *= -1;
                //right side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor-(obstacles[obsIndex].yCoor+6))/(balls[ballID].xOldCoor-(obstacles[obsIndex].xCoor+6)))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols == numCols-1) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //bottom side again
                } else {
                    //updating position
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed < 0 && balls[ballID].ySpeed > 0) { //going down left
                //figuring out which side -- force the ball to choose a block
                //for sure right side
                if ((balls[ballID].yOldCoor+6 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor >= obstacles[obsIndex].xCoor+7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex+numCols+1 >= 0 || obsIndex%numCols == numCols-1) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure top side
                } else if ((balls[ballID].yOldCoor+7 <= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor+6))) {
                    //updating position
                    if (obsIndex-numCols-1 < numObstacles) {
                        if (obstacles[obsIndex-numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing y direction
                    balls[ballID].ySpeed *= -1;
                //right side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor+6-(obstacles[obsIndex].yCoor))/(balls[ballID].xOldCoor-(obstacles[obsIndex].xCoor+6.01)))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex+numCols+1 >= 0 || obsIndex%numCols == numCols-1) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex-numCols-1 < numObstacles) {
                        if (obstacles[obsIndex-numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].ySpeed > 0 && balls[ballID].xSpeed == 0)  { //just going down
                //keep xCoor the same bc xSpeed == 0
                balls[ballID].xCoor = balls[ballID].xOldCoor;
                //make yCoor touching the block
                balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                //flip y speed
                balls[ballID].ySpeed *= -1;
            } else if (balls[ballID].ySpeed < 0 && balls[ballID].xSpeed == 0)  { //just going up
                //keep xCoor the same bc xSpeed == 0
                balls[ballID].xCoor = balls[ballID].xOldCoor;
                //make yCoor touching the block
                balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                //flip y speed
                balls[ballID].ySpeed *= -1;
            } else if (balls[ballID].ySpeed == 0 && balls[ballID].xSpeed > 0)  { //just going right
                balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                balls[ballID].yCoor = balls[ballID].yOldCoor;
                //flip x speed
                balls[ballID].xSpeed *= -1;
            } else { //just going left
                balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                balls[ballID].yCoor = balls[ballID].yOldCoor;
                //flip x speed
                balls[ballID].xSpeed *= -1;
            }
        }



        //collision with paddle
        //detecting collision
        if ((balls[ballID].xCoor+6 >= 214) && (balls[ballID].xCoor <= 219)) {
            if ((balls[ballID].yCoor+6 >= paddle.yCoor) && (balls[ballID].yCoor <= paddle.yCoor+paddle.yWidth-1)) {
                //refreshing paddle so a ball sized hole isn't left after collision
                paddle.resetPaddle = 1;
                //setting position to be touching paddle
                balls[ballID].xCoor = 214-7;
                balls[ballID].yCoor = floor((yDif + balls[ballID].yOldCoor)/2);
                //reflecting y speed based on where on the paddle it hit
                //different speeds for different modes (easy, medium, hard)
                if (maxSpeed == 2) {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 8) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 16) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 25) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 29) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 38) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 46) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 2;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 2;
                    }
                } else if (maxSpeed == 4) {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 3) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 7) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 11) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 15) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 18) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 22) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 26) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 28) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 32) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 36) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 39) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 43) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 47) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 51) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 4;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 4;
                    }
                } else {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 2) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -6;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 5) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -6;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 8) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = -5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 11) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 14) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 17) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 20) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 23) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 26) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 28) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 31) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 34) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 37) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 40) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = 4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 43) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 46) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 49) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 52) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 6;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 6;
                    }
                }
            }
        }

        //delete ball trail

        if (GetNumberOfThreads() > 1 && killself != 1)    {
            if (!((balls[ballID].xOldCoor == balls[ballID].xCoor) && (balls[ballID].yOldCoor == balls[ballID].yCoor)))
            {
                LCD_DrawRectangle(balls[ballID].xOldCoor, balls[ballID].yOldCoor, 7, 7,0x0000);
            }
            LCD_DrawRectangle(balls[ballID].xCoor, balls[ballID].yCoor, 7, 7, balls[ballID].ballColor);
        }

        //ending game
        if (points >= maxScore || lives <= 0) {
            //deleting all balls
            for (int i = 0; i < 7; i++) {
                if (i != ballID) {
                    balls[i].alive = 0;
                    G8RTOS_KillThread(i);
                }
            }
            balls[ballID].alive = 0;
            numBalls = 0;
            G8RTOS_AddThread(&gameEndThread,235+gameEndID,gameEndID);
            G8RTOS_KillSelf();
            sleep(15);
        }

        if (killself == 1) {
            killself = 0;
            G8RTOS_KillSelf();
        }
        sleep(15);
    }
}

void createBallThread(void)
{
    while(1)
    {
        if (addBall > 0) { //if triggered by ball creating ball

            //add a ball for every ball added
            for (int i = 0; i < addBall; i++) {

                numBalls++;
                ball_t ball;
                ball.yCoor = rand()%300+10; //random x start location
                ball.xCoor = 200;
                ball.xSpeed = -1;
                ball.ySpeed = rand()%3-1;
                ball.ballColor = 0xfca0;
                ball.alive = 1;

                //ball stuff
                if (numBalls == 1) {
                    balls[0] = ball;
                    G8RTOS_AddThread(&ballThread,244-numBalls,numBalls-1);
                    lives++;
                } else if (numBalls < 8) { //7 is the limit before it gets laggy
                    for (int i = 0; i < numBalls+1; i++) {
                        if (balls[i].alive != 1) {
                            balls[i] = ball;
                            G8RTOS_AddThread(&ballThread,244-i+1,i);
                            lives++;
                            break;
                        }
                    }
                }
            }
            addBall = 0;
        } else if (interruptFlag == 1 && numBalls < 1) { //if triggered by game starting
            //interrupt stuff
            interruptFlag = 0;
            GPIOIntClear(GPIO_PORTC_BASE, GPIO_PIN_4);
            GPIOIntEnable(GPIO_PORTC_BASE, GPIO_PIN_4);
            IntEnable(INT_GPIOC);  //enables NVIC interrupt

            numBalls++;
            ball_t ball;
            ball.yCoor = rand()%300+10; //random x start location
            ball.xCoor = 200;
            ball.xSpeed = -1;
            ball.ySpeed = rand()%3-1;
            ball.ballColor = 0xfaa0;
            ball.alive = 1;

            //ball stuff
            if (numBalls == 1) {
                balls[0] = ball;
                G8RTOS_AddThread(&ballThread,244-numBalls,numBalls-1);
            } else if (numBalls < 8) { //7 is the limit before it gets laggy
                for (int i = 0; i < numBalls+1; i++) {
                    if (balls[i].alive != 1) {
                        balls[i] = ball;
                        G8RTOS_AddThread(&ballThread,244-i+1,i);
                        break;
                    }
                }
            }
        } else if (interruptFlag == 1) {
            interruptFlag = 0;
            GPIOIntClear(GPIO_PORTC_BASE, GPIO_PIN_4);
            GPIOIntEnable(GPIO_PORTC_BASE, GPIO_PIN_4);
            IntEnable(INT_GPIOC);  //enables NVIC interrupt

            invincible *= -1;
            questionUp = 0;
            //remove the invincible indicator.points from the scoreboard
            LCD_DrawRectangle(0,0,30,40,0x0128);
        }
        sleep(100);
    }
}

//obstacle drawer
void drawObstaclesThread(void)
{
    //drawing design
    //row 1
    obstacles[5].color = 0x0400;
    obstacles[6].color = 0x0400;
    //row 2
    //dark green
    obstacles[16].color = 0x0400;
    obstacles[19].color = 0x0400;
    //light green
    obstacles[17].color = 0x47e8;
    obstacles[18].color = 0x47e8;
    //row 3
    //dark green
    obstacles[28].color = 0x0400;
    obstacles[31].color = 0x0400;
    obstacles[32].color = 0x0400;
    //light green
    obstacles[30].color = 0x47e8;
    //black
    obstacles[29].color = 0x0;
    //row 4
    //dark green
    obstacles[40].color = 0x0400;
    obstacles[43].color = 0x0400;
    obstacles[45].color = 0x0400;
    //light green
    obstacles[41].color = 0x47e8;
    obstacles[42].color = 0x47e8;
    obstacles[44].color = 0x47e8;
    //row 5
    //dark green
    obstacles[53].color = 0x0400;
    obstacles[55].color = 0x0400;
    obstacles[57].color = 0x0400;
    //light green
    obstacles[54].color = 0x47e8;
    obstacles[56].color = 0x47e8;
    //row 6
    //dark green
    obstacles[64].color = 0x0400;
    obstacles[67].color = 0x0400;
    obstacles[69].color = 0x0400;
    //light green
    obstacles[65].color = 0x47e8;
    obstacles[66].color = 0x47e8;
    obstacles[68].color = 0x47e8;
    //row 7
    //dark green
    obstacles[74].color = 0x0400;
    obstacles[75].color = 0x0400;
    obstacles[79].color = 0x0400;
    obstacles[81].color = 0x0400;
    //light green
    obstacles[76].color = 0x47e8;
    obstacles[77].color = 0x47e8;
    obstacles[78].color = 0x47e8;
    obstacles[80].color = 0x47e8;
    //row 8
    //dark green
    obstacles[85].color = 0x0400;
    obstacles[90].color = 0x0400;
    obstacles[93].color = 0x0400;
    //light green
    obstacles[86].color = 0x47e8;
    obstacles[87].color = 0x47e8;
    obstacles[88].color = 0x47e8;
    obstacles[89].color = 0x47e8;
    obstacles[91].color = 0x47e8;
    obstacles[92].color = 0x47e8;
    //row 9
    //dark green
    obstacles[96].color = 0x0400;
    obstacles[105].color = 0x0400;
    //white
    obstacles[98].color = 0xffff;
    //black
    obstacles[99].color = 0x0;
    //light green
    obstacles[97].color = 0x47e8;
    obstacles[100].color = 0x47e8;
    obstacles[101].color = 0x47e8;
    obstacles[102].color = 0x47e8;
    obstacles[103].color = 0x47e8;
    obstacles[104].color = 0x47e8;
    //row 10
    //dark green
    obstacles[108].color = 0x0400;
    obstacles[117].color = 0x0400;
    //black
    obstacles[110].color = 0x0;
    obstacles[111].color = 0x0;
    //light green
    obstacles[109].color = 0x47e8;
    obstacles[112].color = 0x47e8;
    obstacles[113].color = 0x47e8;
    obstacles[114].color = 0x47e8;
    obstacles[115].color = 0x47e8;
    obstacles[116].color = 0x47e8;
    //row 11
    //dark green
    obstacles[121].color = 0x0400;
    obstacles[129].color = 0x0400;
    //light green
    obstacles[122].color = 0x47e8;
    obstacles[123].color = 0x47e8;
    obstacles[124].color = 0x47e8;
    obstacles[125].color = 0x47e8;
    obstacles[126].color = 0x47e8;
    obstacles[127].color = 0x47e8;
    obstacles[128].color = 0x47e8;
    //row 12
    //dark green
    obstacles[134].color = 0x0400;
    obstacles[140].color = 0x0400;
    obstacles[142].color = 0x0400;
    //light green
    obstacles[135].color = 0x47e8;
    obstacles[136].color = 0x47e8;
    obstacles[137].color = 0x47e8;
    obstacles[138].color = 0x47e8;
    obstacles[139].color = 0x47e8;
    //row 12
    //dark green
    obstacles[147].color = 0x0400;
    obstacles[148].color = 0x0400;
    obstacles[151].color = 0x0400;
    obstacles[153].color = 0x0400;
    obstacles[155].color = 0x0400;
    //light green
    obstacles[149].color = 0x47e8;
    obstacles[150].color = 0x47e8;
    obstacles[152].color = 0x47e8;
    obstacles[154].color = 0x47e8;
    //row 13
    //dark green
    obstacles[159].color = 0x0400;
    obstacles[167].color = 0x0400;
    //light green
    obstacles[160].color = 0x47e8;
    obstacles[161].color = 0x47e8;
    obstacles[162].color = 0x47e8;
    obstacles[163].color = 0x47e8;
    obstacles[164].color = 0x47e8;
    obstacles[165].color = 0x47e8;
    obstacles[166].color = 0x47e8;
    //row 14
    //dark green
    obstacles[170].color = 0x0400;
    obstacles[173].color = 0x0400;
    obstacles[178].color = 0x0400;
    //light green
    obstacles[171].color = 0x47e8;
    obstacles[172].color = 0x47e8;
    obstacles[174].color = 0x47e8;
    obstacles[175].color = 0x47e8;
    obstacles[176].color = 0x47e8;
    obstacles[177].color = 0x47e8;
    //row 15
    //dark green
    obstacles[183].color = 0x0400;
    obstacles[185].color = 0x0400;
    obstacles[189].color = 0x0400;
    //light green
    obstacles[184].color = 0x47e8;
    obstacles[186].color = 0x47e8;
    obstacles[187].color = 0x47e8;
    obstacles[188].color = 0x47e8;
    //row 16
    //dark green
    obstacles[194].color = 0x0400;
    obstacles[201].color = 0x0400;
    //light green
    obstacles[195].color = 0x47e8;
    obstacles[196].color = 0x47e8;
    obstacles[197].color = 0x47e8;
    obstacles[198].color = 0x47e8;
    obstacles[199].color = 0x47e8;
    obstacles[200].color = 0x47e8;
    //row 17
    //dark green
    obstacles[207].color = 0x0400;
    obstacles[209].color = 0x0400;
    obstacles[213].color = 0x0400;
    obstacles[214].color = 0x0400;
    //light green
    obstacles[208].color = 0x47e8;
    obstacles[210].color = 0x47e8;
    obstacles[211].color = 0x47e8;
    obstacles[212].color = 0x47e8;
    //row 19
    //dark green
    obstacles[218].color = 0x0400;
    obstacles[221].color = 0x0400;
    obstacles[225].color = 0x0400;
    obstacles[227].color = 0x0400;
    //light green
    obstacles[219].color = 0x47e8;
    obstacles[220].color = 0x47e8;
    obstacles[222].color = 0x47e8;
    obstacles[223].color = 0x47e8;
    obstacles[224].color = 0x47e8;
    obstacles[226].color = 0x47e8;
    //row 20
    //dark green
    obstacles[231].color = 0x0400;
    obstacles[237].color = 0x0400;
    obstacles[239].color = 0x0400;
    //light green
    obstacles[232].color = 0x47e8;
    obstacles[233].color = 0x47e8;
    obstacles[234].color = 0x47e8;
    obstacles[235].color = 0x47e8;
    obstacles[236].color = 0x47e8;
    obstacles[238].color = 0x47e8;
    //row 21
    //dark green
    obstacles[244].color = 0x0400;
    obstacles[249].color = 0x0400;
    obstacles[250].color = 0x0400;
    //light green
    obstacles[245].color = 0x47e8;
    obstacles[246].color = 0x47e8;
    obstacles[247].color = 0x47e8;
    obstacles[248].color = 0x47e8;
    //row 22
    //dark green
    obstacles[257].color = 0x0400;
    obstacles[263].color = 0x0400;
    //light green
    obstacles[258].color = 0x47e8;
    obstacles[259].color = 0x47e8;
    obstacles[260].color = 0x47e8;
    obstacles[261].color = 0x47e8;
    obstacles[262].color = 0x47e8;
    //row 23
    //dark green
    obstacles[269].color = 0x0400;
    obstacles[272].color = 0x0400;
    obstacles[275].color = 0x0400;
    //light green
    obstacles[270].color = 0x47e8;
    obstacles[271].color = 0x47e8;
    obstacles[273].color = 0x47e8;
    obstacles[274].color = 0x47e8;
    //row 24
    //dark green
    obstacles[280].color = 0x0400;
    obstacles[283].color = 0x0400;
    obstacles[285].color = 0x0400;
    obstacles[286].color = 0x0400;
    //light green
    obstacles[281].color = 0x47e8;
    obstacles[282].color = 0x47e8;
    //row 25
    //dark green
    obstacles[291].color = 0x0400;
    obstacles[295].color = 0x0400;
    //light green
    obstacles[292].color = 0x47e8;
    obstacles[293].color = 0x47e8;
    obstacles[294].color = 0x47e8;
    //row 26
    //dark green
    obstacles[302].color = 0x0400;
    obstacles[306].color = 0x0400;
    //light green
    obstacles[303].color = 0x47e8;
    obstacles[304].color = 0x47e8;
    obstacles[305].color = 0x47e8;
    //row 27
    //dark green
    obstacles[313].color = 0x0400;
    obstacles[316].color = 0x0400;
    obstacles[317].color = 0x0400;
    //light green
    obstacles[314].color = 0x47e8;
    obstacles[315].color = 0x47e8;
    //row 28
    //dark green
    obstacles[324].color = 0x0400;
    obstacles[325].color = 0x0400;
    obstacles[326].color = 0x0400;
    obstacles[327].color = 0x0400;
    //row 29
    //dark green
    obstacles[336].color = 0x0400;
    obstacles[337].color = 0x0400;
    //zoom marks
    for (int i = 360; i < 432; i++) {
        if ((i%12 == 3) || (i%12 == 6) || (i%12 == 9)) {
            obstacles[i].color = 0xdefb; //gray
        }
    }

    while(1)
    {
        maxScore = 0;
        for (int i = 0; i < numObstacles; i++) {
            LCD_DrawRectangle(obstacles[i].xCoor,obstacles[i].yCoor,blockWidth,blockWidth,obstacles[i].color);
            if (obstacles[i].color != 0x0) {
                obstacles[i].alive = 1;
                maxScore++;
            }
        }
        G8RTOS_KillSelf();
        sleep(200);
    }
}


void paddleThread(void)
{
    paddle.yCoor = 135;
    paddle.yOldCoor = 135;
    paddle.xWidth = 6;
    paddle.yWidth = 50;
    paddle.yAddedSpeed = 0;
    paddle.resetPaddle = 0;
    //drawing paddle
    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth, 0xfca0);
    //drawing borders bc both paddle and borders will only be present during gameplay
    //right border
    LCD_DrawRectangle(35, 0, 285, 5, 0x0128); //right border
    //bottom border
    LCD_DrawRectangle(235, 5, 5, 315, 0x0128); //bottom border
    //left border
    LCD_DrawRectangle(35, 315, 280, 5, 0x0128); //left border
    //scoreboard
    LCD_DrawRectangle(0, 0, 35, 320, 0x0128); //scoreboard
    //resetting points and lives, then drawing them
    points = 0;
    drawBanner();

    while(1)
    {
        //saving old coordinates
        paddle.yOldCoor = paddle.yCoor;
        paddle.xWidth = 6;
        paddle.yWidth = 50;

        //  save this for paddle
        paddle.yAddedSpeed = FIFOaccelY/125;
        if (paddle.yAddedSpeed > 15) {
            paddle.yAddedSpeed = 15;
        } else if (paddle.yAddedSpeed < -15) {
            paddle.yAddedSpeed = -15;
        }
        int16_t yDif = paddle.yCoor + paddle.yAddedSpeed;

        //checking for wall
        if (yDif >= 265) {
            paddle.yCoor = 265;
        } else if (yDif <= 5)   {
            paddle.yCoor = 5;
        } else {
            paddle.yCoor = yDif;
        }


        //delete ball trail
        if ((paddle.yOldCoor != paddle.yCoor) || paddle.resetPaddle == 1)
        {
            if (paddle.yCoor >= paddle.yOldCoor) {
                //old paddle
                LCD_DrawRectangle(214, paddle.yOldCoor, paddle.xWidth, paddle.yCoor-paddle.yOldCoor,0x0);
                //new paddle
                if (paddle.resetPaddle == 0) {
                    LCD_DrawRectangle(214, paddle.yOldCoor+paddle.yWidth, paddle.xWidth, paddle.yCoor-paddle.yOldCoor,0xfca0);
                } else {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth,0xfca0);
//                    paddle.resetPaddle = 0;
                }
            } else {
                //old paddle
                LCD_DrawRectangle(214, paddle.yCoor+paddle.yWidth, paddle.xWidth, paddle.yOldCoor-paddle.yCoor,0x0);
                //new paddle
                if (paddle.resetPaddle == 0) {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yOldCoor-paddle.yCoor,0xfca0);
                } else {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth,0xfca0);
//                    paddle.resetPaddle = 0;
                }
            }
        }
        sleep(20);
    }
}



void PthreadReadAccels(void) //read accelerometers x and y
{
    //sensor i2c wait semaphore
    G8RTOS_WaitSemaphore(Sensor_I2C);

    //read sensor data and release sensor semaphore
    bmi160_read_accel_x(&accelerometerX);
    G8RTOS_SignalSemaphore(Sensor_I2C);

    // write value to temperature FIFO
    writeFIFO(0, accelerometerX);
//    // grabs the X-coordinate from the
//    GetJoystickCoordinates(&joystickData);
//    // write to joystick FIFO
//    writeFIFO(2,joystickData);
}


void PthreadReadFIFOs(void) //read accelerometer fifos x and y
{
    // read accel FIFO
    Avg= -readFIFO(0);//switching them up b/c the board is oriented not the right way
//    FIFOJoystick = readFIFO(2);
    // smooth the value: calculate decaying average
    FIFOaccelY = (Avg + 2*FIFOaccelY)/3;
}

void PthreadFixScreen(void) //read accelerometer fifos x and y
{
    LCD_Fix();
}


