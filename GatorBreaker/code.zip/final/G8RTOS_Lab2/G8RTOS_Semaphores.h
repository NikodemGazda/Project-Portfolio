/**
 * G8RTOS_Semaphores.h
 * uP2 - Fall 2022
 */
#ifndef G8RTOS_SEMAPHORES_H_
#define G8RTOS_SEMAPHORES_H_

// headers and externs
#include <stdint.h>

// Semaphore typedef
typedef int32_t semaphore_t;
int32_t IBit_State;

/*
 * Initializes a semaphore to a given value
 * Parameter "s": Pointer to semaphore
 * Parameter "value": Value to initialize semaphore to
 */
void G8RTOS_InitSemaphore(semaphore_t *s, int32_t value);

/*
 * Waits for a semaphore to be available (value greater than 0)
 * 	- Decrements semaphore when available
 * 	- Spinlocks to wait for semaphore
 * Parameter "s": Pointer to semaphore to wait on
 */
void G8RTOS_WaitSemaphore(semaphore_t *s);

/*
 * Signals the completion of the usage of a semaphore
 * 	- Increments the semaphore value by 1
 * Parameter "s": Pointer to semaphore to be signalled
 */
void G8RTOS_SignalSemaphore(semaphore_t *s);


#endif /* G8RTOS_SEMAPHORES_H_ */
