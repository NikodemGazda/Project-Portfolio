/**
 * G8RTOS_Structure.h
 * uP2 - Fall 2022
 */
#include <stdbool.h>
#ifndef G8RTOS_STRUCTURES_H_
#define G8RTOS_STRUCTURES_H_

#include "G8RTOS_Semaphores.h"
#include <G8RTOS_Lab2/G8RTOS.h>

/*
 *  Thread Control Block:
 *      - Every thread has a Thread Control Block
 *      - The Thread Control Block holds information about the Thread Such as
 *        the Stack Pointer, Priority Level, and Blocked Status
 *      - For Lab 2 the TCB will only hold the Stack Pointer, next TCB and the
 *        previous TCB (for Round Robin Scheduling)
 *  Create thread control block structure here
 *      - paying close attention to the order of the elements
 * */

#define MAX_NAME_LENGTH 16

typedef int32_t threadId_t;

typedef struct tcb_t
{
    // Add three pointers: stackPointer, nextTCB, and previousTCB
    int32_t *stackPointer;
    struct tcb_t *nextTCB;
    struct tcb_t *previousTCB;
    semaphore_t *blocked;
    uint32_t sleepCount;
    bool asleep;
    uint8_t priority;
    bool isAlive;
    char Threadname[MAX_NAME_LENGTH];
    threadId_t ThreadID;
} tcb_t;

/*
 *  Periodic Thread Control Block:
 *      - Holds a function pointer that points to the periodic thread to be executed
 *      - Has a period in us
 *      - Holds Current time
 *      - Contains pointer to the next periodic event - linked list
 */
typedef struct ptcb_t {
    void (*handler)(void);
    uint32_t period;
    uint32_t executeTime;
    uint32_t currentTime;
    struct ptcb_t *previousPTCB;
    struct ptcb_t *nextPTCB;
} ptcb_t;

tcb_t * CurrentlyRunningThread;

#endif /* G8RTOS_STRUCTURES_H_ */
