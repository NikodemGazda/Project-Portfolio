/**
 * G8RTOS.h
 * uP2 - Fall 2022
 */
#ifndef G8RTOS_H_
#define G8RTOS_H_

#include <G8RTOS_Lab2/G8RTOS_Scheduler.h>
#include <G8RTOS_Lab2/G8RTOS_Semaphores.h>
#include <stdint.h>
#include "G8RTOS_Structures.h"

#endif /* G8RTOS_H_ */
