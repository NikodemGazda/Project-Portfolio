/*
 * BoardInitialization.h
 */

#ifndef BOARDSUPPORT_BOARDINITIALIZATION_H_
#define BOARDSUPPORT_BOARDINITIALIZATION_H_

#include <stdbool.h>

// Function Prototypes
bool InitializeBoard(void);

#endif /* BOARDSUPPORT_BOARDINITIALIZATION_H_ */
