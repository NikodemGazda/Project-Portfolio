#ifndef THREADS_H_
#define THREADS_H_

#include <G8RTOS_Lab2/G8RTOS_Semaphores.h>
#include "G8RTOS_Structures.h"

//lab 4
#define MAX_BALLS 15

#define COOR_FIFO 0
#define numObstacles 432
#define numRows 36
#define numCols 12
#define blockWidth 7

// define semaphore

// Struct object for a 'ball' thread
typedef struct ball_t
{
    int32_t ballID;
    int16_t xCoor;
    int16_t xOldCoor;
    int16_t yCoor;
    int16_t yOldCoor;
    uint16_t ballColor;
    uint16_t prevCol;
    uint16_t alive;
    int16_t xSpeed;
    int16_t ySpeed;
} ball_t;

ball_t balls[20];

typedef struct obstacle_t
{
    int8_t collision;
    int16_t xCoor;
    int16_t yCoor;
    uint16_t color;
    uint8_t alive;
    uint8_t special;
} obstacle_t;

obstacle_t obstacles[numObstacles];

typedef struct paddle_t
{
    int16_t yCoor;
    int16_t yOldCoor;
    int16_t xWidth;
    int16_t yWidth;
    int16_t yAddedSpeed;
    int16_t resetPaddle;
} paddle_t;

// Define array of ball threads

// define your functions

// Semaphores
semaphore_t * Sensor_I2C;
semaphore_t * LED_I2C;
semaphore_t * LCD_Draw;
semaphore_t * joystickSem;

#define JOYSTICKFIFO 0
#define TEMPFIFO 1
#define LIGHTFIFO 2

semaphore_t *sensorMutex;
semaphore_t *LEDMutex;

void Button0(void);
//ball
void MainMenu(void);
void idleThread(void);
void BackGroundThread01(void);
void ballThread(void);
void BackGroundThread2(void);
void BackGroundThread3(void);
void BackGroundThread4(void);

void PthreadReadAccels(void);
void PthreadReadFIFOs(void);
void PthreadPS(void);


// Threads
void Thread0(void);
void Thread1(void);
void Thread2(void);

#endif /* THREADS_H_ */
