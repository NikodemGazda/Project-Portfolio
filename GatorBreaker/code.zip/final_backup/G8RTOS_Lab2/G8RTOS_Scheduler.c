/**
 * G8RTOS_Scheduler.c
 * uP2 - Fall 2022
 */

//Dependencies and Externs
#include <G8RTOS_Lab2/G8RTOS_Scheduler.h>
#include <G8RTOS_Lab2/G8RTOS_Structures.h>
#include <stdint.h>
#include <stdbool.h>
#include "driverlib/systick.h"
#include "driverlib/sysctl.h"
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "inc/tm4c123gh6pm.h"
#include "driverlib/interrupt.h"
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_nvic.h"
#include "G8RTOS_CriticalSection.h"
#include "BoardSupport/inc/RGBLedDriver.h"
#include <time.h>
#include <stdlib.h>



// Holds the current time for the whole System
uint32_t SystemTime;

extern tcb_t * CurrentlyRunningThread;

uint16_t currentMaxPriority = 255;

tcb_t *tempNextThread;

// G8RTOS_Start exists in asm
extern void G8RTOS_Start();

/* System Core Clock From system_msp432p401r.c */
extern uint32_t SystemCoreClock;

// Pointer to the currently running Thread Control Block
extern tcb_t * CurrentlyRunningThread;

// Status Register with the Thumb-bit Set
#define THUMBBIT 0x01000000

// Thread Control Blocks - array to hold information for each thread
static tcb_t threadControlBlocks[MAX_THREADS];

// Thread Stacks - array of arrays for individual stacks of each thread
static int32_t threadStacks[MAX_THREADS][STACKSIZE];

// Periodic Event Threads - array to hold pertinent information for each thread
static ptcb_t Pthread[MAXPTHREADS];

// Current Number of Periodic Threads currently in the scheduler
static uint32_t NumberOfPthreads;

// Current Number of Threads currently in the scheduler
static uint32_t NumberOfThreads;

uint32_t newVTORTable = 0x20000000;
uint32_t *newTable;

/*
 * Initializes the SysTick and SysTick Interrupt
 * The SysTick interrupt will be responsible for starting a context switch between threads
 * Parameter "numCycles": Number of cycles for each sysTick interrupt
 */
static void InitSysTick(uint32_t numberOfCycles)
{
    // Checkout the BoardSupport > driverlib > systick functions

    //disable both for safety idk
    //SysTickDisable();
    //SysTickIntDisable();

    //initialize period
    SysTickPeriodSet(numberOfCycles);

    //enable systick and interrupt
    SysTickEnable();
    SysTickIntEnable();
}


/*
 * Chooses the next thread to run.
 * Lab 2 Scheduling Algorithm:
 * 	- Simple Round Robin: Choose the next running thread by selecting the currently running thread's next pointer
 */
/*
 * Chooses the next thread to run.
 * Lab 3 Scheduling Algorithm:
 *  - Choose the next running thread by selecting the currently running thread's next pointer
 *  - Then check for sleeping and blocked threads
 */
void G8RTOS_Scheduler()
{

    tcb_t *nextThread = CurrentlyRunningThread;
    currentMaxPriority = 256;

    //priority scheduler
    for(int i = 0; i < NumberOfThreads; i++)    {
        if ( (!nextThread->asleep) && (nextThread->blocked == 0))   {
            if (nextThread->priority < currentMaxPriority)  {
                CurrentlyRunningThread = nextThread;
                currentMaxPriority = CurrentlyRunningThread->priority;
            }
        }
        nextThread = nextThread->nextTCB;
    }
}



/*
 * SysTick Handler
 *  - Currently the SysTick Handler will only increment the system time
 *  - and set the PendSV flag to start the scheduler
 *  - In Lab 3, this function will also handle sleeping and periodic threads
 */
void SysTick_IntHandler()
{
	SystemTime++;
	//getting current threads
	tcb_t *ptr = CurrentlyRunningThread;
	ptcb_t *Pptr = &Pthread[0];

	//periodic threads
	for (uint8_t i = 0; i < NumberOfPthreads; i++)  {
	    if ((SystemTime%(Pptr->period)) == Pptr->executeTime)   {
	        Pptr->handler();
	        break;
	    }
	    Pptr = Pptr->nextPTCB;
	}

	//background threads
	for(uint8_t i = 0; i < NumberOfThreads; i++)    {
	    if(ptr->sleepCount <= SystemTime)   {
	        ptr->asleep = 0;
	    }
	    ptr = ptr->nextTCB;
	}

	//context switch
	HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
}



/* G8RTOS_Init
 * - Sets variables to an initial state (system time and number of threads)
 * - Enables board for highest speed clock, WatchDog timer is disabled by default
 */
void G8RTOS_Init()
{
	// Initialize system time to zero
    SystemTime = 0;
	// Set the number of threads to zero
    NumberOfThreads = 0;
    NumberOfPthreads = 0;
    time_t t;
    srand((unsigned) time(&t));
//    srand(time(NULL));
	// Initialize all hardware on the board
    //InitializeBoard();
    //interrupt vector table
    newTable = (uint32_t*)newVTORTable;
    uint32_t * oldTable = (uint32_t *)0;
    for (int i = 0; i < 155; i++)
    {
    newTable[i] = oldTable[i];
    }
    HWREG(NVIC_VTABLE) = newVTORTable;
}


/* Starts G8RTOS Scheduler
 * 	- Initializes the SysTick
 * 	- Sets Context to first thread
 * 	- Set priorities of PendSV and SysTick interrupts to the lowest option
 * 	- Start G8RTOS
 * Returns: Error Code for starting scheduler. This will only return if the scheduler fails
 */
int G8RTOS_Launch()
{
    InitSysTick(SysCtlClockGet() / 1000); // 1 ms tick (1Hz / 1000)
    
	// add your code
    //set currentlyRunningThread to 0
    CurrentlyRunningThread = &threadControlBlocks[0];

    tcb_t *nextThread = CurrentlyRunningThread;
    currentMaxPriority = nextThread->priority;

    //priority scheduler
    for(int i = 0; i < NumberOfThreads; i++)    {
        if ( (!nextThread->asleep) && (nextThread->blocked == 0))   {
            if (nextThread->priority < currentMaxPriority)  {
                CurrentlyRunningThread = nextThread;
                currentMaxPriority = CurrentlyRunningThread->priority;
            }
        }
        nextThread = nextThread->nextTCB;
    }

    //set pendsv and systick to lowest priorities
    HWREG(NVIC_SYS_PRI3) |= NVIC_SYS_PRI3_PENDSV_M;
    HWREG(NVIC_SYS_PRI3) |= NVIC_SYS_PRI3_TICK_M;
    //IntPrioritySet(NVIC_SYS_PRI3_PENDSV_M, 0xE0);
    //IntPrioritySet(NVIC_SYS_PRI3_TICK_M, 0xE0);

    G8RTOS_Start(); // call the assembly function
    return 0;
}


/* G8RTOS_AddThread
 *  - Adds threads to G8RTOS Scheduler
 * 	- Checks if there are still available threads to insert to scheduler
 * 	- Initializes the thread control block for the provided thread
 * 	- Initializes the stack for the provided thread to hold a "fake context"
 * 	- Sets stack thread control block stack pointer to top of thread stack
 * 	- Sets up the next and previous thread control block pointers in a round robin fashion
 * Parameter "threadToAdd": Void-Void Function to add as pre-emptable main thread
 * Returns: Error code for adding threads
 */
sched_ErrCode_t G8RTOS_AddThread(void (*threadToAdd)(void), uint8_t bigP, int32_t threadID)
{
    IBit_State = StartCriticalSection();

    sched_ErrCode_t errtype = NO_ERROR;
	if (NumberOfThreads > MAX_THREADS)
	{
	    errtype = THREAD_LIMIT_REACHED;
	}
	else
	{
	    uint8_t newThreadIndex = 0;
	    if (NumberOfThreads == 0)
	    {
			// There is only one thread (in the linked list), so both the next and previous threads are itself
	        threadControlBlocks[0].nextTCB = &threadControlBlocks[0];
	        threadControlBlocks[0].previousTCB = &threadControlBlocks[0];
	        CurrentlyRunningThread = &threadControlBlocks[0];
	    }
	    else
	    {
			/* 
			Append the new thread to the end of the linked list
			* 1. Number of threads will refer to the newest thread to be added since the current index would be NumberOfThreads-1
			* 2. Set the next thread for the new thread to be the first in the list, so that round-robin will be maintained
			* 3. Set the current thread's nextTCB to be the new thread
			* 4. Set the first thread's previous thread to be the new thread, so that it goes in the right spot in the list
			* 5. Point the previousTCB of the new thread to the current thread so that it moves in the correct order
			*/
	        for(uint8_t i = 0;i < MAX_THREADS;i++)
            {
                if(threadControlBlocks[i].isAlive == 0)
                {
                    newThreadIndex = i;
                    break;
                }
            }
	        CurrentlyRunningThread->nextTCB->previousTCB = &threadControlBlocks[newThreadIndex];
            threadControlBlocks[newThreadIndex].nextTCB =  CurrentlyRunningThread->nextTCB;
            CurrentlyRunningThread->nextTCB = &threadControlBlocks[newThreadIndex]; //set next tcb
            threadControlBlocks[newThreadIndex].previousTCB = CurrentlyRunningThread; //set previous tcb

//            threadControlBlocks[NumberOfThreads].nextTCB = &threadControlBlocks[0];
//	        threadControlBlocks[NumberOfThreads-1].nextTCB = &threadControlBlocks[NumberOfThreads];
//	        threadControlBlocks[0].previousTCB = &threadControlBlocks[NumberOfThreads];
//	        threadControlBlocks[NumberOfThreads].previousTCB = &threadControlBlocks[NumberOfThreads-1];
	    }

	    // Set up the stack pointer
	    threadControlBlocks[newThreadIndex].stackPointer = &threadStacks[newThreadIndex][STACKSIZE - 16];
	    threadStacks[newThreadIndex][STACKSIZE - 1] = THUMBBIT;
	    threadStacks[newThreadIndex][STACKSIZE - 2] = (uint32_t)threadToAdd;

	    // Increment number of threads present in the scheduler
	    threadControlBlocks[newThreadIndex].priority = bigP;
//	    for(int i = 0; i < threadNameSize; i++) {
//	        threadControlBlocks[NumberOfThreads].Threadname[i] = threadName[i];
//	    }
	    threadControlBlocks[newThreadIndex].ThreadID = threadID;
	    threadControlBlocks[newThreadIndex].isAlive = true;
	    NumberOfThreads++;
	    EndCriticalSection(IBit_State);
	}
	return errtype;
}

/*
 * Adds periodic threads to G8RTOS Scheduler
 * Function will initialize a periodic event struct to represent event.
 * The struct will be added to a linked list of periodic events
 * Param Pthread To Add: void-void function for P thread handler
 * Param period: period of P thread to add
 * Returns: Error code for adding threads
 */
int G8RTOS_AddPeriodicEvent(void (*PthreadToAdd)(void), uint32_t period, uint32_t execution)
{
    // your code
    if (NumberOfPthreads > MAXPTHREADS)
        {
            return 0;
        }
        else
        {
            if (NumberOfPthreads == 0)
            {
                Pthread[0].nextPTCB = &Pthread[0];
                Pthread[0].previousPTCB = &Pthread[0];
            }
            else
            {
                Pthread[NumberOfPthreads].nextPTCB = &Pthread[0];
                Pthread[NumberOfPthreads-1].nextPTCB = &Pthread[NumberOfPthreads];
                Pthread[0].previousPTCB = &Pthread[NumberOfPthreads];
                Pthread[NumberOfPthreads].previousPTCB = &Pthread[NumberOfPthreads-1];
            }

            //assign handler
            Pthread[NumberOfPthreads].handler = PthreadToAdd;

            //assign period and execution times
            Pthread[NumberOfPthreads].period = period;
            Pthread[NumberOfPthreads].executeTime = execution;

            // Increment number of threads present in the scheduler
            NumberOfPthreads++;
        }
        return 1;
}

sched_ErrCode_t G8RTOS_AddAPeriodicEvent(void (*AthreadToAdd)(void), uint8_t priority, int32_t IRQn, uint8_t pin)
{
    newTable[IRQn] = AthreadToAdd;


    IntPrioritySet(IRQn,priority);
    // Initialize PB4 as input
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOC);
    GPIOPinTypeGPIOInput(GPIO_PORTC_BASE, pin);
    GPIO_PORTC_PUR_R |= 0x10;

    // Initialize pin and base port interrupt on falling edgemasked interrupt status
    GPIOIntClear(GPIO_PORTC_BASE, pin);
    GPIOIntTypeSet(GPIO_PORTC_BASE, pin, GPIO_FALLING_EDGE);
    GPIOIntEnable(GPIO_PORTC_BASE, pin);
    IntEnable(IRQn);
    return NO_ERROR;
}

/*
 * Puts the current thread into a sleep state.
 *  param durationMS: Duration of sleep time in ms
 */
void sleep(uint32_t durationMS)
{
    CurrentlyRunningThread->sleepCount = durationMS + SystemTime;   //Sets sleep count
    CurrentlyRunningThread->asleep = 1;                             //Puts the thread to sleep
    HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;                  //Start context switch
}

threadId_t G8RTOS_GetThreadId()
{
    return CurrentlyRunningThread->ThreadID;        //Returns the thread ID
}

sched_ErrCode_t G8RTOS_KillThread(threadId_t threadID)
{
    IBit_State = StartCriticalSection();
    sched_ErrCode_t errorType = NO_ERROR;

    //if no threads scheduled
    if (NumberOfThreads == 0)   {
        errorType = NO_THREADS_SCHEDULED;
    //if only one thread scheduled
    } else if (NumberOfThreads == 1)    {
        errorType = THREAD_LIMIT_REACHED;
    }

    bool threadIDinList = false;
    tcb_t *nxtThread = CurrentlyRunningThread;

    //setting thread's isAlive to false
    if (errorType == NO_ERROR)  {
        for (int i = 0; i < NumberOfThreads; i++)
        {
            if (nxtThread->ThreadID == threadID)
            {
                threadIDinList = true;
                if (nxtThread->isAlive)
                {
                    nxtThread->isAlive = false;
                    break;
                }
            }
            nxtThread = nxtThread->nextTCB;
        }

        //returning error if thread with given ID doesn't exist
        if (!threadIDinList)
        {
            errorType = THREAD_DOES_NOT_EXIST;
        }

        if (errorType == NO_ERROR)   {
            //removing thread from linked list of active threads
            nxtThread->previousTCB->nextTCB = nxtThread->nextTCB;
            nxtThread->nextTCB->previousTCB = nxtThread->previousTCB;

            //decrementing number of threads
            NumberOfThreads--;
        }
    }
    EndCriticalSection(IBit_State);

    //context switch if the killed thread is the currently running thread
    if (CurrentlyRunningThread->ThreadID == nxtThread->ThreadID)   {
        HWREG(NVIC_INT_CTRL) |= NVIC_INT_CTRL_PEND_SV;
    }

    return errorType;
}

void G8RTOS_KillSelf()
{
    G8RTOS_KillThread(CurrentlyRunningThread->ThreadID);
}

uint32_t GetNumberOfThreads(void)
{
    return NumberOfThreads;         //Returns the number of threads
}

void G8RTOS_KillAllThreads()
{
    // your code
}



