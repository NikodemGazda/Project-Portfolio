#include <BoardSupport/inc/bmi160.h>
#include <BoardSupport/inc/Joystick.h>
#include <BoardSupport/inc/opt3001.h>
#include <BoardSupport/inc/RGBLedDriver.h>
#include <G8RTOS_Lab2/G8RTOS_IPC.h>
#include <G8RTOS_Lab2/G8RTOS_Scheduler.h>
#include <sys/_stdint.h>
#include <threads.h>
#include <utils/uartstdio.h>
#include "inc/hw_types.h"
#include "inc/hw_ints.h"
#include "inc/hw_nvic.h"
#include <stdlib.h>
#include <time.h>
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "inc/tm4c123gh6pm.h"
#include <stdio.h>
#include <math.h>

int16_t accelerometerX;
int32_t Avg = 0;
int16_t FIFOaccelY;
int32_t FIFOJoystick;
int16_t squareCount = 0;
uint8_t interruptFlag = 0;
uint16_t numBalls = 0;
uint8_t add_delete = 0;
uint8_t clear_flag = 0;
uint16_t obstaclesX[15];
uint16_t obstaclesY[15];
uint16_t LCDFlag = 0;
int8_t invincible = -1;
paddle_t paddle;
int16_t maxSpeed = 4;
int16_t points = 0;
int16_t lives = 10;
int16_t state = 0;
uint16_t addBall = 0;

int16_t abs16(int16_t a);
int16_t abs16(int16_t a) {
    if (a < 0) {
        return a*-1;
    } else {
        return a;
    }
}

void drawOrange6x6(uint16_t x, uint16_t y, uint16_t color);
void drawOrange6x6(uint16_t x, uint16_t y, uint16_t color) {
    //POINTS
    LCD_DrawRectangle(x+2,y,6,6,color);
}

void drawBanner();
void drawBanner() {
    //POINTS
    //P
    drawOrange6x6(0,302,0xfca0);
    drawOrange6x6(6,302,0xfca0);
    drawOrange6x6(12,302,0xfca0);
    drawOrange6x6(0,304,0xfca0);
    drawOrange6x6(12,304,0xfca0);
    drawOrange6x6(0,310,0xfca0);
    drawOrange6x6(6,310,0xfca0);
    drawOrange6x6(12,310,0xfca0);
    drawOrange6x6(18,310,0xfca0);
    drawOrange6x6(24,310,0xfca0);
    //O
    LCD_DrawRectangle(2,294,30,6,0xfca0);
    LCD_DrawRectangle(2,286,30,6,0xfca0);
    drawOrange6x6(24,292,0xfca0);
    drawOrange6x6(0,292,0xfca0);
    //I
    LCD_DrawRectangle(2,278,30,6,0xfca0);
    //N
    LCD_DrawRectangle(2,270,30,6,0xfca0);
    LCD_DrawRectangle(2,268,6,2,0xfca0);
    LCD_DrawRectangle(2,262,30,6,0xfca0);
    //T
    LCD_DrawRectangle(2,247,6,13,0xfca0);
    LCD_DrawRectangle(2,250,30,6,0xfca0);
    //S
    LCD_DrawRectangle(2,241,18,4,0xfca0);
    LCD_DrawRectangle(14,231,18,4,0xfca0);
    drawOrange6x6(0,231,0xfca0);
    drawOrange6x6(0,235,0xfca0);
    drawOrange6x6(12,235,0xfca0);
    drawOrange6x6(24,235,0xfca0);
    drawOrange6x6(24,239,0xfca0);
    //:
    drawOrange6x6(6,219,0xfca0);
    drawOrange6x6(18,219,0xfca0);
    //LIVES
    //L
    LCD_DrawRectangle(2,133,30,6,0xfca0);
    LCD_DrawRectangle(26,121,6,12,0xfca0);
    //I
    LCD_DrawRectangle(2,113,30,6,0xfca0);
    //V
    LCD_DrawRectangle(2,105,18,6,0xfca0);
    LCD_DrawRectangle(2,93,18,6,0xfca0);
    drawOrange6x6(18,102,0xfca0);
    drawOrange6x6(18,96,0xfca0);
    drawOrange6x6(24,99,0xfca0);
    //E
    LCD_DrawRectangle(2,85,30,6,0xfca0);
    drawOrange6x6(0,79,0xfca0);
    drawOrange6x6(12,79,0xfca0);
    drawOrange6x6(24,79,0xfca0);
    //S
    LCD_DrawRectangle(2,71,18,4,0xfca0);
    LCD_DrawRectangle(14,61,18,4,0xfca0);
    drawOrange6x6(0,61,0xfca0);
    drawOrange6x6(0,65,0xfca0);
    drawOrange6x6(12,65,0xfca0);
    drawOrange6x6(24,65,0xfca0);
    drawOrange6x6(24,69,0xfca0);
    //:
    drawOrange6x6(6,49,0xfca0);
    drawOrange6x6(18,49,0xfca0);
    //points and lives
}


//lab 4

//aperiodic thread

void Button0(void)   {
    GPIOIntDisable(GPIO_PORTC_BASE, GPIO_PIN_4);
    IntDisable(INT_GPIOC);  //Disables NVIC interrupt
    interruptFlag = 1;
}






void idleThread(void)
{
    while(1);
}

void MainMenu(void);

void BackGroundThread01(void)
{
    lives = 10;
    points = 0;
    uint16_t oldLives = lives;
    uint16_t oldPoints = points;
    uint16_t temp = 0;
    while(1) {
        if (oldLives != lives) {
            temp = oldLives;
            //erasing old vals
            for (int i = 0; i < 2; i++) {
                PutChar(18+12*i,26,temp%10+48,0x1f);
                temp /= 10;
            }
            temp = lives;
            for (int i = 0; i < 2; i++) {
                PutChar(18+12*i,26,temp%10+48,0xffff);
                temp /= 10;
            }
            oldLives = lives;
        }
        if (oldPoints != points) {
            temp = oldPoints;
            //erasing old vals
            if ((temp/10)%10 != (points/10)%10) {
                LCD_DrawRectangle(14,165,12,32,0x1f);
            } else {
                for (int i = 0; i < 3; i++) {
                    PutChar(173+12*i,26,temp%10+48,0x1f);
                    temp /= 10;
                }
            }
            temp = points;
            for (int i = 0; i < 3; i++) {
                PutChar(173+12*i,26,temp%10+48,0xffff);
                temp /= 10;
            }
            oldPoints = points;
        }
        sleep(1000); //update every 5 seconds
    }
}


void ballThread(void)
{

    ball_t ball0;
    uint16_t ballID = CurrentlyRunningThread->ThreadID;
    ball0.xCoor = 200; //random x start location
    ball0.yCoor = rand()%300+10; //random x start location
    ball0.xSpeed = -1;
    ball0.ySpeed = rand()%3-1;
    ball0.ballColor = 0xfca0;
    ball0.alive = 1;
    balls[ballID] = ball0;
    while(1)
    {

        //save old xCoor and yCoor to erase previous ball
        if (clear_flag == 0)    {
        balls[ballID].xOldCoor = balls[ballID].xCoor;
        balls[ballID].yOldCoor = balls[ballID].yCoor;

        //ball motion
        int16_t xDif = balls[ballID].xCoor + balls[ballID].xSpeed;
        int16_t yDif = balls[ballID].yCoor + balls[ballID].ySpeed;

        //checking for wall and bouncing if collision
        if (xDif >= 228) {
            if (invincible == 1) {
                balls[ballID].xSpeed *= -1;
                balls[ballID].xCoor = 228;
            } else {
                // [1, 1]
                //numBalls = 2
                // [0 ,1]
                //numBalls = 1
                // [0, 2]!!!
                balls[ballID].alive = 0;
                LCD_DrawRectangle(balls[ballID].xOldCoor,balls[ballID].yOldCoor,7,7,0x0000);
                LCD_DrawRectangle(balls[ballID].xCoor,balls[ballID].yCoor,7,7,0x0000);
                numBalls--;
                lives--;
                G8RTOS_KillSelf();
                sleep(15);
            }
        } else if (xDif <= 35)   {
            balls[ballID].xSpeed *= -1;
            balls[ballID].xCoor = 35;
        } else {
            //updating x position
            balls[ballID].xCoor = xDif;
        }

        if (yDif >= 308) {
            balls[ballID].ySpeed *= -1;
            balls[ballID].yCoor = 308;
        } else if (yDif <= 5)   {
            balls[ballID].ySpeed *= -1;
            balls[ballID].yCoor = 5;
        } else {
            //updating y position
            balls[ballID].yCoor = yDif;
        }

        //collision with obstacle
        uint16_t colFlag = 0;
        uint16_t colx[5] = {0,0,0,0,0};
        int16_t minColDist = 25;
        int16_t obsIndex = 0;
        for (int i = 0; i < numObstacles; i++)  {
            if (obstacles[i].alive == 1) {
                //seeing if the ball is within the x range of the obstacle
                if ( (xDif+6 >= obstacles[i].xCoor) && (xDif <= obstacles[i].xCoor+blockWidth) )   {
                    //seeing if the ball is within the y range of the obstacle
                    if ( (yDif+6 >= obstacles[i].yCoor) && (yDif <= obstacles[i].yCoor+blockWidth) )   {
                        colFlag = 1;
                        int16_t test = (abs16(balls[ballID].xOldCoor - obstacles[i].xCoor) + abs16(balls[ballID].yOldCoor - obstacles[i].yCoor));
                        if (test < minColDist ) {
                            minColDist = test;
                            obsIndex = i;
                        }
                        obstacles[i].collision = 1;
                        for (int k = 0; k < 5; k++) {
                            if (colx[k] == 0) {
                                colx[k] = i;
                                break;
                            } else {
                                break;
                            }
                        }
                    }
                }
            }
        }

        //if collision detected
        if (colFlag == 1) {

            //removing obstacle
            obstacles[obsIndex].alive = 0;
            LCD_DrawRectangle(obstacles[obsIndex].xCoor, obstacles[obsIndex].yCoor, blockWidth, blockWidth,0x0000);
            points++;
            if (obstacles[obsIndex].special == 9) {
                addBall++;
            }

            //also figure out the direction it's going in
            if (balls[ballID].xSpeed > 0 && balls[ballID].ySpeed > 0) { //going down right
                //figuring out which side -- force the ball to choose a block
                //for sure left side
                if ((balls[ballID].yOldCoor+6 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor-7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    //The position after collision is going to be touching where the
                    //obstacle used to be. While touching the obstacle, it would look
                    //better if the position where the ball is touching where the obstacle
                    //used to be were somewhere between the old position and where the new
                    //position would've been had the obstacle not been there, however, this
                    //causes errors if that better position ends up in another obstacle.
                    //therefore, the following if statements check if there's a block in the
                    //better position--if not, that'll be the position. If so, the new position
                    //will snap back to the closest safest location.
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure top side
                } else if ((balls[ballID].yOldCoor+7 <= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor+6 >= obstacles[obsIndex].xCoor))) {
                    //updating position
                    //the first if statement checks if that position is even possible
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                //left side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor+6-obstacles[obsIndex].yCoor)/(balls[ballID].xOldCoor+6.01-obstacles[obsIndex].xCoor))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed > 0 && balls[ballID].ySpeed < 0) { //going up right
                //figuring out which side -- force the ball to choose a block
                //for sure left side
                if ((balls[ballID].yOldCoor <= obstacles[obsIndex].yCoor+6) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor-7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex-numCols-1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure bottom side
                } else if ((balls[ballID].yOldCoor-7 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor+6 >= obstacles[obsIndex].xCoor))) {
                    //updating position
                    if (obsIndex+numCols+1 < numObstacles) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                //left side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor-(obstacles[obsIndex].yCoor+6))/(balls[ballID].xOldCoor+6.01-obstacles[obsIndex].xCoor))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                    if (obsIndex-numCols-1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols==0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex+numCols+1 < numObstacles) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed < 0 && balls[ballID].ySpeed < 0) { //going up left
                //figuring out which side -- force the ball to choose a block
                //for sure right side
                if ((balls[ballID].yOldCoor <= obstacles[obsIndex].yCoor+6) && ((balls[ballID].xOldCoor >= obstacles[obsIndex].xCoor+7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols == numCols-1) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure bottom side
                } else if ((balls[ballID].yOldCoor >= obstacles[obsIndex].yCoor+7) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor+6))) {
                    //updating position
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing y direction
                    balls[ballID].ySpeed *= -1;
                //right side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor-(obstacles[obsIndex].yCoor+6))/(balls[ballID].xOldCoor-(obstacles[obsIndex].xCoor+6)))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex-numCols+1 >= 0) {
                        if (obstacles[obsIndex-numCols-1].alive == 0 || obsIndex%numCols == numCols-1) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //bottom side again
                } else {
                    //updating position
                    if (obsIndex+numCols-1 < numObstacles) {
                        if (obstacles[obsIndex+numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].xSpeed < 0 && balls[ballID].ySpeed > 0) { //going down left
                //figuring out which side -- force the ball to choose a block
                //for sure right side
                if ((balls[ballID].yOldCoor+6 >= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor >= obstacles[obsIndex].xCoor+7))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex+numCols+1 >= 0 || obsIndex%numCols == numCols-1) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //for sure top side
                } else if ((balls[ballID].yOldCoor+7 <= obstacles[obsIndex].yCoor) && ((balls[ballID].xOldCoor <= obstacles[obsIndex].xCoor+6))) {
                    //updating position
                    if (obsIndex-numCols-1 < numObstacles) {
                        if (obstacles[obsIndex-numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing y direction
                    balls[ballID].ySpeed *= -1;
                //right side again
                } else if (abs16((double)balls[ballID].ySpeed/(balls[ballID].xSpeed+0.01)) > abs16((double)(balls[ballID].yOldCoor+6-(obstacles[obsIndex].yCoor))/(balls[ballID].xOldCoor-(obstacles[obsIndex].xCoor+6.01)))) {
                    //updating position
                    balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                    if (obsIndex+numCols+1 >= 0 || obsIndex%numCols == numCols-1) {
                        if (obstacles[obsIndex+numCols+1].alive == 0) {
                            balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                        } else {
                            balls[ballID].yCoor = obstacles[obsIndex].yCoor;
                        }
                    } else {
                        balls[ballID].yCoor = floor((balls[ballID].yOldCoor + yDif)/2);
                    }
                    //reversing x direction
                    balls[ballID].xSpeed *= -1;
                //top side again
                } else {
                    //updating position
                    if (obsIndex-numCols-1 < numObstacles) {
                        if (obstacles[obsIndex-numCols-1].alive == 0) {
                            balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                        } else {
                            balls[ballID].xCoor = obstacles[obsIndex].xCoor;
                        }
                    } else {
                        balls[ballID].xCoor = floor((balls[ballID].xOldCoor + xDif)/2);
                    }
                    balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                    //reversing x direction
                    balls[ballID].ySpeed *= -1;
                }
            } else if (balls[ballID].ySpeed > 0 && balls[ballID].xSpeed == 0)  { //just going down
                //keep xCoor the same bc xSpeed == 0
                balls[ballID].xCoor = balls[ballID].xOldCoor;
                //make yCoor touching the block
                balls[ballID].yCoor = obstacles[obsIndex].yCoor-7;
                //flip y speed
                balls[ballID].ySpeed *= -1;
            } else if (balls[ballID].ySpeed < 0 && balls[ballID].xSpeed == 0)  { //just going up
                //keep xCoor the same bc xSpeed == 0
                balls[ballID].xCoor = balls[ballID].xOldCoor;
                //make yCoor touching the block
                balls[ballID].yCoor = obstacles[obsIndex].yCoor+7;
                //flip y speed
                balls[ballID].ySpeed *= -1;
            } else if (balls[ballID].ySpeed == 0 && balls[ballID].xSpeed > 0)  { //just going right
                balls[ballID].xCoor = obstacles[obsIndex].xCoor-7;
                balls[ballID].yCoor = balls[ballID].yOldCoor;
                //flip x speed
                balls[ballID].xSpeed *= -1;
            } else { //just going left
                balls[ballID].xCoor = obstacles[obsIndex].xCoor+7;
                balls[ballID].yCoor = balls[ballID].yOldCoor;
                //flip x speed
                balls[ballID].xSpeed *= -1;
            }
        }



        //collision with paddle
        //detecting collision
        if ((balls[ballID].xCoor+6 >= 214) && (balls[ballID].xCoor <= 219)) {
            if ((balls[ballID].yCoor+6 >= paddle.yCoor) && (balls[ballID].yCoor <= paddle.yCoor+paddle.yWidth-1)) {
                //refreshing paddle so a ball sized hole isn't left after collision
                paddle.resetPaddle = 1;
                //setting position to be touching paddle
                balls[ballID].xCoor = 214-7;
                balls[ballID].yCoor = floor((yDif + balls[ballID].yOldCoor)/2);
                //reflecting y speed based on where on the paddle it hit
                //different speeds for different modes (easy, medium, hard)
                if (maxSpeed == 2) {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 8) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 16) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 25) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 29) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 38) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 46) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 2;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 2;
                    }
                } else if (maxSpeed == 4) {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 3) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 7) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 11) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 15) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 18) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 22) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 26) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 28) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 32) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 36) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 39) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 43) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 47) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 51) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 4;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 4;
                    }
                } else {
                    if (balls[ballID].yCoor+6 - paddle.yCoor <= 2) {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = -6;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 5) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = -6;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 8) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = -5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 11) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 14) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 17) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 20) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = -3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 23) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = -2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 26) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = -1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 28) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 0;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 31) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 1;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 34) {
                        balls[ballID].xSpeed = -6;
                        balls[ballID].ySpeed = 2;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 37) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = 3;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 40) {
                        balls[ballID].xSpeed = -5;
                        balls[ballID].ySpeed = 4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 43) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 4;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 46) {
                        balls[ballID].xSpeed = -4;
                        balls[ballID].ySpeed = 5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 49) {
                        balls[ballID].xSpeed = -3;
                        balls[ballID].ySpeed = 5;
                    } else if (balls[ballID].yCoor+6 - paddle.yCoor <= 52) {
                        balls[ballID].xSpeed = -2;
                        balls[ballID].ySpeed = 6;
                    } else {
                        balls[ballID].xSpeed = -1;
                        balls[ballID].ySpeed = 6;
                    }
                }
            }
        }

        //delete ball trail

        if (GetNumberOfThreads() > 1)    {
            if (!((balls[ballID].xOldCoor == balls[ballID].xCoor) && (balls[ballID].yOldCoor == balls[ballID].yCoor)))
            {
                LCD_DrawRectangle(balls[ballID].xOldCoor, balls[ballID].yOldCoor, 7, 7,0x0000);
            }
            LCD_DrawRectangle(balls[ballID].xCoor, balls[ballID].yCoor, 7, 7, balls[ballID].ballColor);
        }



        }
        sleep(15);
    }
}

void BackGroundThread2(void)
{
//    time_t t;
//    srand((unsigned) time(&t));
    while(1)
    {
        if (addBall > 0) { //if triggered by ball creating ball

            //add a ball for every ball added
            for (int i = 0; i < addBall; i++) {
                addBall--;
                numBalls++;
                ball_t ball;
                ball.xCoor = 200;
                ball.yCoor = 156; //random x start location
                ball.xSpeed = -maxSpeed;
                ball.ySpeed = 0;
                ball.ballColor = 0xfca0;
                ball.alive = 1;

                //ball stuff
                if (numBalls == 1) {
                    balls[0] = ball;
                    G8RTOS_AddThread(&ballThread,245-numBalls,numBalls-1);
                    lives++;
                } else if (numBalls < 8) { //7 is the limit before it gets laggy
                    for (int i = 0; i < numBalls+1; i++) {
                        if (balls[i].alive != 1) {
                            balls[i] = ball;
                            G8RTOS_AddThread(&ballThread,245-i+1,i);
                            lives++;
                            break;
                        }
                    }
                }
            }
        } else if (interruptFlag == 1) { //if triggered by game starting
            //interrupt stuff
            interruptFlag = 0;
            GPIOIntClear(GPIO_PORTC_BASE, GPIO_PIN_4);
            GPIOIntEnable(GPIO_PORTC_BASE, GPIO_PIN_4);
            IntEnable(INT_GPIOC);  //enables NVIC interrupt

            numBalls++;
            ball_t ball;
            ball.xCoor = 200;
            ball.yCoor = 156; //random x start location
            ball.xSpeed = -maxSpeed;
            ball.ySpeed = 0;
            ball.ballColor = 0x1f;
            ball.alive = 1;

            //ball stuff
            if (numBalls == 1) {
                balls[0] = ball;
                G8RTOS_AddThread(&ballThread,245-numBalls,numBalls-1);
                lives++;
            } else if (numBalls < 8) { //7 is the limit before it gets laggy
                for (int i = 0; i < numBalls+1; i++) {
                    if (balls[i].alive != 1) {
                        balls[i] = ball;
                        G8RTOS_AddThread(&ballThread,245-i+1,i);
                        lives++;
                        break;
                    }
                }
            }
        } else if (numBalls < 1 && lives > 10) {
            numBalls++;
        }
        sleep(100);
    }
}

//obstacle drawer
void BackGroundThread3(void)
{

    while(1)
    {
        for (int i = 0; i < numObstacles; i++) {
            LCD_DrawRectangle(obstacles[i].xCoor,obstacles[i].yCoor,blockWidth,blockWidth,0xFFFF);
        }
        G8RTOS_KillSelf();
        sleep(200);
    }
}


void BackGroundThread4(void)
{
    paddle.yCoor = 135;
    paddle.yOldCoor = 135;
    paddle.xWidth = 6;
    paddle.yWidth = 50;
    paddle.yAddedSpeed = 0;
    paddle.resetPaddle = 0;
    //drawing paddle
    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth, 0xfca0);
    //drawing borders bc both paddle and borders will only be present during gameplay
    //right border
    LCD_DrawRectangle(35, 0, 285, 5, 0x1f); //right border
    //bottom border
    LCD_DrawRectangle(235, 5, 5, 315, 0x1f); //bottom border
    //left border
    LCD_DrawRectangle(35, 315, 280, 5, 0x1f); //left border
    //scoreboard
    LCD_DrawRectangle(0, 0, 35, 320, 0x1f); //scoreboard
    //resetting points and lives, then drawing them
    points = 0;
    lives = 10;
    drawBanner();

    while(1)
    {
        if (state != 2) {

        }
        //saving old coordinates
        paddle.yOldCoor = paddle.yCoor;
        paddle.xWidth = 6;
        paddle.yWidth = 50;

        //  save this for paddle
        paddle.yAddedSpeed = FIFOaccelY/150;
        if (paddle.yAddedSpeed > 15) {
            paddle.yAddedSpeed = 15;
        } else if (paddle.yAddedSpeed < -15) {
            paddle.yAddedSpeed = -15;
        }
        int16_t yDif = paddle.yCoor + paddle.yAddedSpeed;

        //checking for wall
        if (yDif >= 265) {
            paddle.yCoor = 265;
        } else if (yDif <= 5)   {
            paddle.yCoor = 5;
        } else {
            paddle.yCoor = yDif;
        }


        //delete ball trail
        if ((paddle.yOldCoor != paddle.yCoor) || paddle.resetPaddle == 1)
        {
            if (paddle.yCoor >= paddle.yOldCoor) {
                //old paddle
                LCD_DrawRectangle(214, paddle.yOldCoor, paddle.xWidth, paddle.yCoor-paddle.yOldCoor,0x0);
                //new paddle
                if (paddle.resetPaddle == 0) {
                    LCD_DrawRectangle(214, paddle.yOldCoor+paddle.yWidth, paddle.xWidth, paddle.yCoor-paddle.yOldCoor,0xfca0);
                } else {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth,0xfca0);
//                    paddle.resetPaddle = 0;
                }
            } else {
                //old paddle
                LCD_DrawRectangle(214, paddle.yCoor+paddle.yWidth, paddle.xWidth, paddle.yOldCoor-paddle.yCoor,0x0);
                //new paddle
                if (paddle.resetPaddle == 0) {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yOldCoor-paddle.yCoor,0xfca0);
                } else {
                    LCD_DrawRectangle(214, paddle.yCoor, paddle.xWidth, paddle.yWidth,0xfca0);
//                    paddle.resetPaddle = 0;
                }
            }
        }


        sleep(20);
    }
}



void PthreadReadAccels(void) //read accelerometers x and y
{
    //sensor i2c wait semaphore
    G8RTOS_WaitSemaphore(Sensor_I2C);

    //read sensor data and release sensor semaphore
    bmi160_read_accel_x(&accelerometerX);
    G8RTOS_SignalSemaphore(Sensor_I2C);

    // write value to temperature FIFO
    writeFIFO(0, accelerometerX);
//    // grabs the X-coordinate from the joystick
//    GetJoystickCoordinates(&joystickData);
//    // write to joystick FIFO
//    writeFIFO(2,joystickData);
}


void PthreadReadFIFOs(void) //read accelerometer fifos x and y
{
    Avg= -readFIFO(0);//switching them up b/c the board is oriented not the right way
    // read joystick FIFO
//    FIFOJoystick = readFIFO(2);
    // smooth the value: calculate decaying average
    FIFOaccelY = (Avg + FIFOaccelY)/2;
}


