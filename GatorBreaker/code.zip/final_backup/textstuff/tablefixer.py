# with open ("corrected_text.txt",'r') as file:
#     var = file.read()
#     newVar = [0 for i in range(67200)]
#     for x in range(len(var)):
#         if (x%10 < 2):
#             newVar[int(x/10)*7+x%10] = var[x]
#         elif (x%10 >= 2 and x%10 < 4):
#             newVar[int(x/10)*7+x%10+2] = var[x]
#         elif (x%10 >= 7 and x%10 < 9):
#             newVar[int(x/10)*7+x%10-5] = var[x]
#         elif (x%10 == 9):
#             newVar[int(x/10)*7+x%10-3] = var[x]    
#     file.close()
#     pass
# with open("color_data2.txt",'w') as file:
#     for x in range(67200):
#         file.write(newVar[x])
#     file.close()
#     pass
# with open("idk.txt",'r') as file:
#     spaces = file.read()
#     space = spaces[1]
#     file.close()
#     pass
# with open("color_data2.txt",'r') as file:
#     var = file.read()
#     newVar = [0 for i in range(67680)]
#     offset = 0
#     for x in range(len(var)):
#         newVar[x] = var[x]
#     count = 0
#     for x in range(len(var)):
#         if var[x] == ',':
#             count+=1
#         if (count == 20):
#             count = 0
#             newVar.insert(x+1+offset,space)
#             offset+=1
#     file.close()
#     pass
# with open("color_data3.txt",'w') as file:
#     for x in range(67680):
#         file.write(str(newVar[x]))
#     file.close()
#     pass
with open("color_data2.txt",'r') as file:
    var = file.read()
    count = 0
    unique = [0 for i in range(67680)]
    for x in range(0,len(var)-14,7):
        for y in range(7):
            if var[x+y] != var[x+y+7]:
                count+=1
    print(count)