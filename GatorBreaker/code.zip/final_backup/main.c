                /**
 * main.c
 * @author:
 * uP2 - Fall 2022
 */

// Required headers and definitions
#include <G8RTOS_Lab2/G8RTOS_Semaphores.h>
#include <G8RTOS_Lab2/G8RTOS_Structures.h>
#include "threads.h"
#include "driverlib/watchdog.h"
#include "inc/hw_memmap.h"
#include "inc/tm4c123gh6pm.h"
#include "BoardSupport/inc/BoardInitialization.h"
#include <stdbool.h>


void BSP_InitBoard(void);   //Function prototype

int main(void)
{

    // Initialize the G8RTOS
    G8RTOS_Init();
    // Initialize the BSP
    bool isBoardSetup = InitializeBoard(); // initialize board
    // Initialize Sensor semaphore
    //G8RTOS_InitSemaphore(LCD_SPI,1);
    // Initialize LED semaphore
    //G8RTOS_InitSemaphore(LED_I2C,1);
    // Initialize the three FIFOs
    G8RTOS_InitFIFO(0); //accel x
    G8RTOS_InitFIFO(1); //accel y

    G8RTOS_InitFIFO(2); //LCD_DrawRectangle
    // Add background thread 0 to 4
    //char emptyThread[] = {'e','0'};
    //char ball0name[] = {'b','0'};
    //char timer[] = {'t','0'};

    G8RTOS_AddThread(&idleThread,255,16);
    G8RTOS_AddThread(&BackGroundThread01,251,20);
    G8RTOS_AddThread(&BackGroundThread2,254,17);
    G8RTOS_AddThread(&BackGroundThread3,253,18); //load obstacles
    G8RTOS_AddThread(&BackGroundThread4,252,19); //paddle

    //creating obstacles

    uint16_t obsCounter = 0;
    for (int i = 0; i < 36; i++)    {
        for (int j = 0; j < 12; j++)    {
            obstacles[obsCounter].xCoor = 45 + j*(blockWidth+1);
            obstacles[obsCounter].yCoor = 15 + i*(blockWidth+1);
            obstacles[obsCounter].alive = 1;
            obstacles[obsCounter].collision = 0;
            obstacles[obsCounter].special = rand()%10;
            obsCounter++;
        }
    }



    // Add periodic thread 0 and 1
    G8RTOS_AddPeriodicEvent(&PthreadReadAccels,50,0);
    G8RTOS_AddPeriodicEvent(&PthreadReadFIFOs,50,1);


    // Launch the G8RTOScurrentMaxPriority
    G8RTOS_Launch();

	while(1){}
}


