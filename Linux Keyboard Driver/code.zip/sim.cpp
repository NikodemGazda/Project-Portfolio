#include "sim.hpp"

// check sim.hpp for structs and such

/********** functions/threads **********/
// callback functions that get registered with the Input subsystem
void usb_kbd_open() {
    // initialize the kbd_dev struct
    kbd_dev.dev = (struct input_dev*)malloc(sizeof(struct input_dev));
    kbd_dev.int_buf = '[';
    kbd_dev.int_buf_old = '[';
    kbd_dev.dev->led = false;
    kbd_dev.led_urb_submitted = false;
    kbd_dev.done = false;

    // call usb_submit_urb() for the first time
    usb_submit_urb(OPEN);
    
}

void *usb_kbd_event(void* arg) {
    // writing to led_buffer
    if(kbd_dev.int_buf == '@') {
        *led_buffer = 1;
    }
    return NULL;
}

// input layer
void input_report_key(usb_event event) {
    // if event is caps, create usb_kbd_event thread
    if (event == CAPS) {
        // recording caps press
        if (kbd_dev.int_buf == '@') {
            kbd_dev.dev->led = !kbd_dev.dev->led;
        }

        // create usb_kbd_event thread
        pthread_create(&usb_kbd_event_thread, NULL, usb_kbd_event, NULL);

        // then join it
        pthread_join(usb_kbd_event_thread, NULL);
    } else {
        write(1, &kbd_dev.int_buf, sizeof(kbd_dev.int_buf));
        // printf("%c", kbd_dev.int_buf);
        // fflush(stdout);
    }
}

// endpoint threads
void *usb_core_int(void* arg) {

    // close write end of pipe
    close(intpipe_fd[1]);
    
    // initialize buffer
    char buffer = '[';

    // wait till the kbd sends ']' to signal it's done
    while (buffer != ']') {
        // read from the pipe
        while(kbd_dev.led_urb_submitted == true);
        read(intpipe_fd[0], &buffer, sizeof(buffer));

        // only register key press if not '#', don't know if I interpreted this correctly
        if (buffer != '#') {
            // check if caps is on
            if (kbd_dev.dev->led == true) {
                // check if lowercase
                if (islower(buffer)) {
                    // convert to uppercase
                    buffer = toupper(buffer);
                } else if (isupper(buffer)) {
                    // convert to lowercase
                    buffer = tolower(buffer);
                }
            }

            // save buffer value in device
            kbd_dev.int_buf = buffer;

            // create usb_kbd_irq thread
            pthread_create(&usb_kbd_irq_thread, NULL, usb_kbd_irq, NULL);
            
            // join the usb_kbd_irq thread
            pthread_join(usb_kbd_irq_thread, NULL);
        }
    }

    // close read end of pipe
    close(intpipe_fd[0]);

    return NULL;
}

void *usb_core_ctrl(void* arg) {

    // close read end of ctrl pipe
    close(ctrlpipe_fd[0]);

    // close write end of ack pipe
    close(ackpipe_fd[1]);

    while(!kbd_dev.done) {
        // wait for a urb to be submitted
        if (kbd_dev.led_urb_submitted == true) {
            // write to the pipe
            char buffer = 'I';
            if (kbd_dev.int_buf_old == 'C') {
                buffer = 'C';

                // create usb_kbd_led thread
                pthread_create(&usb_kbd_led_thread, NULL, usb_kbd_led, NULL);

                // join the usb_kbd_led thread
                pthread_join(usb_kbd_led_thread, NULL);
            }
            write(ctrlpipe_fd[1], &buffer, sizeof(buffer));

            // read ack from the pipe
            read(ackpipe_fd[0], &buffer, sizeof(buffer));

            // reset flag
            kbd_dev.led_urb_submitted = false;
        }
    }
    // send end command
    char buffer = ']';
    write(ctrlpipe_fd[1], &buffer, sizeof(buffer));

    return NULL;
}

void *usb_kbd_int(void* arg) {
    
    // close read end of led pipe
    close(intpipe_fd[0]);

    // close write end of ctrl pipe
    close(ctrlpipe_fd[1]);

    msg = '[';
    // read 1 byte from stdin and store in msg
     
    while(cin.get(msg)) {

        // write msg to the pipe
        write(intpipe_fd[1], &msg, sizeof(msg));

        // wait till the driver allows next message
        while(!urb_received && msg != '#');
        urb_received = false;
    }

    // end of file
    msg = ']';

    // write EOF msg to the pipe
    write(intpipe_fd[1], &msg, sizeof(msg));

    // close write end of pipe
    close(intpipe_fd[1]);

    // close read end of ctrl pipe
    close(ctrlpipe_fd[0]);

    return NULL;
}

void *usb_kbd_ctrl(void* arg) {

    // close read end of led pipe
    close(ackpipe_fd[0]);

    // close write end of ctrl pipe
    close(ctrlpipe_fd[1]);

    // read from the pipe
    int led_value = 0;
    char buffer = '[';
    
    // read from the pipe
    read(ctrlpipe_fd[0], &buffer, sizeof(buffer));

    // loop as long as last byte not yet read
    while (buffer != ']') {
        if (buffer == 'C') {
            // read from led_buffer
            led_value = *led_buffer;

            // send ack to the pipe
            buffer = 'A';
            write(ackpipe_fd[1], &buffer, sizeof(buffer));

            // set value of urb_received to true
            urb_received = true;

            // update led_count based on command
            if (led_value == 1) {
                // toggle caps
                led_count++;
            } // if led_value == 0 do nothing

            if (msg == ']') {
                break;
            }
        } else if (buffer == 'I') {
            // send ack to the pipe
            buffer = 'I';
            write(ackpipe_fd[1], &buffer, sizeof(buffer));

            // set value of urb_received to true
            urb_received = true;
            if (msg == ']') {
                break;
            }
        }
        // read from the pipe
        read(ctrlpipe_fd[0], &buffer, sizeof(buffer));
    }

    // print led_count
    printf("\n");
    for (int i = 0; i < led_count; i++) {
        if (i % 2 == 0) {
            printf("ON ");
        } else {
            printf("OFF ");
        }
    }
    printf("\n");

    // close write end of ack pipe
    close(ackpipe_fd[1]);

    // close read end of ctrl pipe
    close(ctrlpipe_fd[0]);

    return NULL;
}

// URBs
void usb_submit_urb(usb_event event) {
    // only create endpoint threads once
    if (event == OPEN) {
        // Create usb_core threads
        pthread_create(&usb_core_int_thread, NULL, usb_core_int, NULL);        
        pthread_create(&usb_core_ctrl_thread, NULL, usb_core_ctrl, NULL);
    } else if (event == CAPS) {
        // signal we submitted the urb
        kbd_dev.int_buf_old = 'C';
        kbd_dev.led_urb_submitted = true;
    } else if (event == IRQ) {
        // signal we submitted the urb
        kbd_dev.int_buf_old = 'I';
        kbd_dev.led_urb_submitted = true;
    }
}

// completion handler threads
void *usb_kbd_irq(void* arg) {
    // check the value of the buffer
    if (kbd_dev.int_buf == '@' || kbd_dev.int_buf == '&') {
        // call input_report_key
        input_report_key(CAPS);

        // call usb_submit_urb
        usb_submit_urb(CAPS);
    } else if (kbd_dev.int_buf == ']') {
        // signal we're done
        kbd_dev.done = true;
    } else {
        // call input_report_key
        input_report_key(IRQ);
        // call usb_submit_urb
        usb_submit_urb(IRQ);
    }

    return NULL;
}

void *usb_kbd_led(void* arg) {
    // if the int_buf has '&' write to led_buffer
    if (kbd_dev.int_buf == '&') {
        *led_buffer = 0;
    }
    return NULL;
}

/********** main function **********/
int main(int argc, char* argv[]) {

    // initialize the shared led_buffer
    led_buffer = (int*)mmap(NULL, sizeof(int), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);

    // create pipes
    if (pipe(intpipe_fd) == -1) {
        perror("intpipe_fd");
        return -1;
    }

    if (pipe(ackpipe_fd) == -1) {
        perror("ackpipe_fd");
        return -1;
    }

    if (pipe(ctrlpipe_fd) == -1) {
        perror("ctrlpipe_fd");
        return -1;
    }
    
    // fork for driver
    pid_t pid = fork();
    if (pid == 0) {
        // call open
        usb_kbd_open();

        // join threads
        pthread_join(usb_core_int_thread, NULL);
        pthread_join(usb_core_ctrl_thread, NULL);

        // exit
        exit(0);
    }

    // fork for keyboard
    pid = fork();
    if (pid == 0) {
        // create usb_kbd_int_thread and usb_kbd_ctrl_thread
        pthread_create(&usb_kbd_int_thread, NULL, usb_kbd_int, NULL);
        pthread_create(&usb_kbd_ctrl_thread, NULL, usb_kbd_ctrl, NULL);

        // join them too
        pthread_join(usb_kbd_int_thread, NULL);
        pthread_join(usb_kbd_ctrl_thread, NULL);
        
        // exit
        exit(0);
    }

    // wait for children to finish
    wait(NULL);
    wait(NULL);

    // unmap the shared led_buffer
    munmap(led_buffer, sizeof(int));

    // free device
    free(kbd_dev.dev);

    return 0;
}