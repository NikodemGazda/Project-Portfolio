// includes
#include <iostream>
#include <cstdlib>
#include <cctype>
#include <stdint.h>
#include <string>
#include <cstring>
#include <sys/mman.h>
#include <unistd.h>
#include <pthread.h>
#include <unordered_map>
#include <list>
#include <sys/wait.h>
#include <semaphore.h>

using namespace std;

// enum
enum usb_event {
    IRQ,
    LED,
    OPEN,
    CAPS
};

// define directives
#define debug 0
#define CHAR_SIZE 100

// global variables
int *led_buffer;
int intpipe_fd[2];
int ackpipe_fd[2];
int ctrlpipe_fd[2];
int led_count = 0;
bool urb_received = true;
char msg;

// threads
// driver
pthread_t usb_core_int_thread, usb_core_ctrl_thread,
          usb_kbd_event_thread, usb_kbd_irq_thread, usb_kbd_led_thread;

// device
pthread_t usb_kbd_int_thread, usb_kbd_ctrl_thread;

// structs
struct usb_kbd {
    struct input_dev *dev;
    char int_buf;
    char int_buf_old;
    // unsigned char newleds;
    int led;
    bool led_urb_submitted;
    bool done;
};

usb_kbd kbd_dev;

struct input_dev {
    void (*usb_kbd_event)(void* arg);
    bool led;
};

/********** functions/threads **********/
// callback functions that get registered with the Input subsystem
void usb_kbd_open();
void *usb_kbd_event(void* arg);

// input layer
void input_report_key();

// endpoint threads
void *usb_core_int(void* arg);
void *usb_core_ctrl(void* arg);
void *usb_kbd_int(void* arg);
void *usb_kbd_ctrl(void* arg);

// URBs
void usb_submit_urb(usb_event event);

// completion handler threads
void *usb_kbd_irq(void* arg);
void *usb_kbd_led(void* arg);